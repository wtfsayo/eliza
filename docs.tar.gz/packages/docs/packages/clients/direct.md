Deprecated: this plugin lives in @elizaos/core
