# Unmaintained: this cache plugin originally lived in @elizaos/core. It needs a maintainer.
