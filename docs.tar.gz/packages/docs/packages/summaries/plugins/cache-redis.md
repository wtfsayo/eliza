# Unmaintained: this cache plugin originally lived in @elizaos/core. It needs a maintainer.

## Purpose
This cache plugin originally lived in @elizaos/core.

## Integration
Originally part of @elizaos/core but now separated.

## Note
Needs a maintainer.
