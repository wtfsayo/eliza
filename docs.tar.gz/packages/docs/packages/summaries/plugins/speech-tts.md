# service-speech-tts

## Purpose
TTS transcription service with OpenAI + ElevenLabs
