# Unmaintained

## Purpose
This plugin used to live in @elizaos/core and needs a maintainer.
