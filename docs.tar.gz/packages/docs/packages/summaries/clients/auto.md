# ElizaOS Plugin

## Purpose
This plugin is a component of ElizaOS.

## Integration
The plugin is now incorporated into @elizaos/core rather than existing as a standalone plugin.

## Links
@elizaos/core
