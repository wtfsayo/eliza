# Query Params

## Purpose
A plugin that provides a way to get query parameters from the URL.

## Integration
This plugin is now part of the @elizaos/core package.
