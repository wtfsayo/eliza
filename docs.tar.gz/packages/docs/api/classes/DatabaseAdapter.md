[@elizaos/core v1.0.0-beta.32](../index.md) / DatabaseAdapter

# Class: `abstract` DatabaseAdapter\<DB\>

Database adapter class to be extended by individual database adapters.

## Implements

## Type Parameters

• **DB** = `unknown`

The type of the database instance.

## Implements

- [`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md)

## Properties

### db

> **db**: `DB`

The database instance.

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`db`](../interfaces/IDatabaseAdapter.md#db)

#### Defined in

[packages/core/src/database.ts:32](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L32)

## Methods

### init()

> `abstract` **init**(): `Promise`\<`void`\>

Initialize the database adapter.

#### Returns

`Promise`\<`void`\>

A Promise that resolves when initialization is complete.

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`init`](../interfaces/IDatabaseAdapter.md#init)

#### Defined in

[packages/core/src/database.ts:38](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L38)

***

### close()

> `abstract` **close**(): `Promise`\<`void`\>

Optional close method for the database adapter.

#### Returns

`Promise`\<`void`\>

A Promise that resolves when closing is complete.

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`close`](../interfaces/IDatabaseAdapter.md#close)

#### Defined in

[packages/core/src/database.ts:44](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L44)

***

### getEntityById()

> `abstract` **getEntityById**(`entityId`): `Promise`\<[`Entity`](../interfaces/Entity.md)\>

Retrieves an account by its ID.

#### Parameters

• **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the user account to retrieve.

#### Returns

`Promise`\<[`Entity`](../interfaces/Entity.md)\>

A Promise that resolves to the Entity object or null if not found.

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`getEntityById`](../interfaces/IDatabaseAdapter.md#getEntityById)

#### Defined in

[packages/core/src/database.ts:51](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L51)

***

### getEntitiesForRoom()

> `abstract` **getEntitiesForRoom**(`roomId`, `includeComponents`?): `Promise`\<[`Entity`](../interfaces/Entity.md)[]\>

Get entities for room

#### Parameters

• **roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **includeComponents?**: `boolean`

#### Returns

`Promise`\<[`Entity`](../interfaces/Entity.md)[]\>

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`getEntitiesForRoom`](../interfaces/IDatabaseAdapter.md#getEntitiesForRoom)

#### Defined in

[packages/core/src/database.ts:53](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L53)

***

### createEntity()

> `abstract` **createEntity**(`entity`): `Promise`\<`boolean`\>

Creates a new entity in the database.

#### Parameters

• **entity**: [`Entity`](../interfaces/Entity.md)

The entity object to create.

#### Returns

`Promise`\<`boolean`\>

A Promise that resolves when the account creation is complete.

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`createEntity`](../interfaces/IDatabaseAdapter.md#createEntity)

#### Defined in

[packages/core/src/database.ts:60](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L60)

***

### updateEntity()

> `abstract` **updateEntity**(`entity`): `Promise`\<`void`\>

Updates an existing entity in the database.

#### Parameters

• **entity**: [`Entity`](../interfaces/Entity.md)

The entity object with updated properties.

#### Returns

`Promise`\<`void`\>

A Promise that resolves when the account update is complete.

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`updateEntity`](../interfaces/IDatabaseAdapter.md#updateEntity)

#### Defined in

[packages/core/src/database.ts:67](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L67)

***

### getComponent()

> `abstract` **getComponent**(`entityId`, `type`, `worldId`?, `sourceEntityId`?): `Promise`\<`Component`\>

Retrieves a single component by entity ID and type.

#### Parameters

• **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the entity the component belongs to

• **type**: `string`

The type identifier for the component

• **worldId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Optional UUID of the world the component belongs to

• **sourceEntityId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Optional UUID of the source entity

#### Returns

`Promise`\<`Component`\>

Promise resolving to the Component if found, null otherwise

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`getComponent`](../interfaces/IDatabaseAdapter.md#getComponent)

#### Defined in

[packages/core/src/database.ts:77](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L77)

***

### getComponents()

> `abstract` **getComponents**(`entityId`, `worldId`?, `sourceEntityId`?): `Promise`\<`Component`[]\>

Retrieves all components for an entity.

#### Parameters

• **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the entity to get components for

• **worldId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Optional UUID of the world to filter components by

• **sourceEntityId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Optional UUID of the source entity to filter by

#### Returns

`Promise`\<`Component`[]\>

Promise resolving to array of Component objects

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`getComponents`](../interfaces/IDatabaseAdapter.md#getComponents)

#### Defined in

[packages/core/src/database.ts:91](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L91)

***

### createComponent()

> `abstract` **createComponent**(`component`): `Promise`\<`boolean`\>

Creates a new component in the database.

#### Parameters

• **component**: `Component`

The component object to create

#### Returns

`Promise`\<`boolean`\>

Promise resolving to true if creation was successful

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`createComponent`](../interfaces/IDatabaseAdapter.md#createComponent)

#### Defined in

[packages/core/src/database.ts:102](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L102)

***

### updateComponent()

> `abstract` **updateComponent**(`component`): `Promise`\<`void`\>

Updates an existing component in the database.

#### Parameters

• **component**: `Component`

The component object with updated properties

#### Returns

`Promise`\<`void`\>

Promise that resolves when the update is complete

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`updateComponent`](../interfaces/IDatabaseAdapter.md#updateComponent)

#### Defined in

[packages/core/src/database.ts:109](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L109)

***

### deleteComponent()

> `abstract` **deleteComponent**(`componentId`): `Promise`\<`void`\>

Deletes a component from the database.

#### Parameters

• **componentId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the component to delete

#### Returns

`Promise`\<`void`\>

Promise that resolves when the deletion is complete

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`deleteComponent`](../interfaces/IDatabaseAdapter.md#deleteComponent)

#### Defined in

[packages/core/src/database.ts:116](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L116)

***

### getMemories()

> `abstract` **getMemories**(`params`): `Promise`\<[`Memory`](../interfaces/Memory.md)[]\>

Retrieves memories based on the specified parameters.

#### Parameters

• **params**

An object containing parameters for the memory retrieval.

• **params.entityId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.agentId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.roomId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.count?**: `number`

• **params.unique?**: `boolean`

• **params.tableName**: `string`

• **params.start?**: `number`

• **params.end?**: `number`

#### Returns

`Promise`\<[`Memory`](../interfaces/Memory.md)[]\>

A Promise that resolves to an array of Memory objects.

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`getMemories`](../interfaces/IDatabaseAdapter.md#getMemories)

#### Defined in

[packages/core/src/database.ts:123](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L123)

***

### getMemoriesByIds()

> `abstract` **getMemoriesByIds**(`memoryIds`, `tableName`?): `Promise`\<[`Memory`](../interfaces/Memory.md)[]\>

Retrieves multiple memories by their IDs

#### Parameters

• **memoryIds**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`[]

Array of UUIDs of the memories to retrieve

• **tableName?**: `string`

Optional table name to filter memories by type

#### Returns

`Promise`\<[`Memory`](../interfaces/Memory.md)[]\>

Promise resolving to array of Memory objects

#### Implementation of

`IDatabaseAdapter.getMemoriesByIds`

#### Defined in

[packages/core/src/database.ts:148](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L148)

***

### getCachedEmbeddings()

> `abstract` **getCachedEmbeddings**(`params`): `Promise`\<`object`[]\>

Retrieves cached embeddings based on the specified query parameters.

#### Parameters

• **params**

An object containing parameters for the embedding retrieval.

• **params.query\_table\_name**: `string`

• **params.query\_threshold**: `number`

• **params.query\_input**: `string`

• **params.query\_field\_name**: `string`

• **params.query\_field\_sub\_name**: `string`

• **params.query\_match\_count**: `number`

#### Returns

`Promise`\<`object`[]\>

A Promise that resolves to an array of objects containing embeddings and levenshtein scores.

#### Implementation of

`IDatabaseAdapter.getCachedEmbeddings`

#### Defined in

[packages/core/src/database.ts:155](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L155)

***

### log()

> `abstract` **log**(`params`): `Promise`\<`void`\>

Logs an event or action with the specified details.

#### Parameters

• **params**

An object containing parameters for the log entry.

• **params.body**

• **params.entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.type**: `string`

#### Returns

`Promise`\<`void`\>

A Promise that resolves when the log entry has been saved.

#### Implementation of

`IDatabaseAdapter.log`

#### Defined in

[packages/core/src/database.ts:181](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L181)

***

### getLogs()

> `abstract` **getLogs**(`params`): `Promise`\<[`Log`](../interfaces/Log.md)[]\>

Retrieves logs based on the specified parameters.

#### Parameters

• **params**

An object containing parameters for the log retrieval.

• **params.entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.roomId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.type?**: `string`

• **params.count?**: `number`

• **params.offset?**: `number`

#### Returns

`Promise`\<[`Log`](../interfaces/Log.md)[]\>

A Promise that resolves to an array of Log objects.

#### Implementation of

`IDatabaseAdapter.getLogs`

#### Defined in

[packages/core/src/database.ts:193](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L193)

***

### deleteLog()

> `abstract` **deleteLog**(`logId`): `Promise`\<`void`\>

Deletes a log from the database.

#### Parameters

• **logId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the log to delete.

#### Returns

`Promise`\<`void`\>

A Promise that resolves when the log has been deleted.

#### Implementation of

`IDatabaseAdapter.deleteLog`

#### Defined in

[packages/core/src/database.ts:206](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L206)

***

### searchMemories()

> `abstract` **searchMemories**(`params`): `Promise`\<[`Memory`](../interfaces/Memory.md)[]\>

Searches for memories based on embeddings and other specified parameters.

#### Parameters

• **params**

An object containing parameters for the memory search.

• **params.tableName**: `string`

• **params.roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.embedding**: `number`[]

• **params.match\_threshold**: `number`

• **params.count**: `number`

• **params.unique**: `boolean`

#### Returns

`Promise`\<[`Memory`](../interfaces/Memory.md)[]\>

A Promise that resolves to an array of Memory objects.

#### Implementation of

`IDatabaseAdapter.searchMemories`

#### Defined in

[packages/core/src/database.ts:213](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L213)

***

### createMemory()

> `abstract` **createMemory**(`memory`, `tableName`, `unique`?): `Promise`\<\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`\>

Creates a new memory in the database.

#### Parameters

• **memory**: [`Memory`](../interfaces/Memory.md)

The memory object to create.

• **tableName**: `string`

The table where the memory should be stored.

• **unique?**: `boolean`

Indicates if the memory should be unique.

#### Returns

`Promise`\<\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`\>

A Promise that resolves when the memory has been created.

#### Implementation of

`IDatabaseAdapter.createMemory`

#### Defined in

[packages/core/src/database.ts:229](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L229)

***

### updateMemory()

> `abstract` **updateMemory**(`memory`): `Promise`\<`boolean`\>

Updates an existing memory in the database.

#### Parameters

• **memory**: `Partial`\<[`Memory`](../interfaces/Memory.md)\> & `object`

The memory object with updated content and optional embedding

#### Returns

`Promise`\<`boolean`\>

Promise resolving to boolean indicating success

#### Implementation of

`IDatabaseAdapter.updateMemory`

#### Defined in

[packages/core/src/database.ts:236](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L236)

***

### deleteMemory()

> `abstract` **deleteMemory**(`memoryId`): `Promise`\<`void`\>

Removes a specific memory from the database.

#### Parameters

• **memoryId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the memory to remove.

#### Returns

`Promise`\<`void`\>

A Promise that resolves when the memory has been removed.

#### Implementation of

`IDatabaseAdapter.deleteMemory`

#### Defined in

[packages/core/src/database.ts:245](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L245)

***

### deleteAllMemories()

> `abstract` **deleteAllMemories**(`roomId`, `tableName`): `Promise`\<`void`\>

Removes all memories associated with a specific room.

#### Parameters

• **roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the room whose memories should be removed.

• **tableName**: `string`

The table from which the memories should be removed.

#### Returns

`Promise`\<`void`\>

A Promise that resolves when all memories have been removed.

#### Implementation of

`IDatabaseAdapter.deleteAllMemories`

#### Defined in

[packages/core/src/database.ts:253](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L253)

***

### countMemories()

> `abstract` **countMemories**(`roomId`, `unique`?, `tableName`?): `Promise`\<`number`\>

Counts the number of memories in a specific room.

#### Parameters

• **roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the room for which to count memories.

• **unique?**: `boolean`

Specifies whether to count only unique memories.

• **tableName?**: `string`

Optional table name to count memories from.

#### Returns

`Promise`\<`number`\>

A Promise that resolves to the number of memories.

#### Implementation of

`IDatabaseAdapter.countMemories`

#### Defined in

[packages/core/src/database.ts:262](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L262)

***

### getWorld()

> `abstract` **getWorld**(`id`): `Promise`\<`World`\>

Retrieves a world by its ID.

#### Parameters

• **id**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the world to retrieve.

#### Returns

`Promise`\<`World`\>

A Promise that resolves to the World object or null if not found.

#### Implementation of

`IDatabaseAdapter.getWorld`

#### Defined in

[packages/core/src/database.ts:269](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L269)

***

### getAllWorlds()

> `abstract` **getAllWorlds**(): `Promise`\<`World`[]\>

Retrieves all worlds for an agent.

#### Returns

`Promise`\<`World`[]\>

A Promise that resolves to an array of World objects.

#### Implementation of

`IDatabaseAdapter.getAllWorlds`

#### Defined in

[packages/core/src/database.ts:275](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L275)

***

### createWorld()

> `abstract` **createWorld**(`world`): `Promise`\<\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`\>

Creates a new world in the database.

#### Parameters

• **world**: `World`

The world object to create.

#### Returns

`Promise`\<\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`\>

A Promise that resolves to the UUID of the created world.

#### Implementation of

`IDatabaseAdapter.createWorld`

#### Defined in

[packages/core/src/database.ts:282](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L282)

***

### updateWorld()

> `abstract` **updateWorld**(`world`): `Promise`\<`void`\>

Updates an existing world in the database.

#### Parameters

• **world**: `World`

The world object with updated properties.

#### Returns

`Promise`\<`void`\>

A Promise that resolves when the world has been updated.

#### Implementation of

`IDatabaseAdapter.updateWorld`

#### Defined in

[packages/core/src/database.ts:289](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L289)

***

### removeWorld()

> `abstract` **removeWorld**(`id`): `Promise`\<`void`\>

Removes a specific world from the database.

#### Parameters

• **id**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the world to remove.

#### Returns

`Promise`\<`void`\>

A Promise that resolves when the world has been removed.

#### Defined in

[packages/core/src/database.ts:296](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L296)

***

### getRoom()

> `abstract` **getRoom**(`roomId`): `Promise`\<`Room`\>

Retrieves the room ID for a given room, if it exists.

#### Parameters

• **roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the room to retrieve.

#### Returns

`Promise`\<`Room`\>

A Promise that resolves to the room ID or null if not found.

#### Implementation of

`IDatabaseAdapter.getRoom`

#### Defined in

[packages/core/src/database.ts:303](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L303)

***

### getRooms()

> `abstract` **getRooms**(`worldId`): `Promise`\<`Room`[]\>

Retrieves all rooms for a given world.

#### Parameters

• **worldId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the world to retrieve rooms for.

#### Returns

`Promise`\<`Room`[]\>

A Promise that resolves to an array of Room objects.

#### Implementation of

`IDatabaseAdapter.getRooms`

#### Defined in

[packages/core/src/database.ts:310](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L310)

***

### createRoom()

> `abstract` **createRoom**(`roomId`): `Promise`\<\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`\>

Creates a new room with an optional specified ID.

#### Parameters

• **roomId**: `Room`

Optional UUID to assign to the new room.

#### Returns

`Promise`\<\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`\>

A Promise that resolves to the UUID of the created room.

#### Implementation of

`IDatabaseAdapter.createRoom`

#### Defined in

[packages/core/src/database.ts:317](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L317)

***

### updateRoom()

> `abstract` **updateRoom**(`room`): `Promise`\<`void`\>

Updates a specific room in the database.

#### Parameters

• **room**: `Room`

The room object with updated properties.

#### Returns

`Promise`\<`void`\>

A Promise that resolves when the room has been updated.

#### Implementation of

`IDatabaseAdapter.updateRoom`

#### Defined in

[packages/core/src/database.ts:324](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L324)

***

### deleteRoom()

> `abstract` **deleteRoom**(`roomId`): `Promise`\<`void`\>

Removes a specific room from the database.

#### Parameters

• **roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the room to remove.

#### Returns

`Promise`\<`void`\>

A Promise that resolves when the room has been removed.

#### Implementation of

`IDatabaseAdapter.deleteRoom`

#### Defined in

[packages/core/src/database.ts:331](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L331)

***

### getRoomsForParticipant()

> `abstract` **getRoomsForParticipant**(`entityId`): `Promise`\<\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`[]\>

Retrieves room IDs for which a specific user is a participant.

#### Parameters

• **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the user.

#### Returns

`Promise`\<\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`[]\>

A Promise that resolves to an array of room IDs.

#### Implementation of

`IDatabaseAdapter.getRoomsForParticipant`

#### Defined in

[packages/core/src/database.ts:338](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L338)

***

### getRoomsForParticipants()

> `abstract` **getRoomsForParticipants**(`userIds`): `Promise`\<\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`[]\>

Retrieves room IDs for which specific users are participants.

#### Parameters

• **userIds**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`[]

An array of UUIDs of the users.

#### Returns

`Promise`\<\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`[]\>

A Promise that resolves to an array of room IDs.

#### Implementation of

`IDatabaseAdapter.getRoomsForParticipants`

#### Defined in

[packages/core/src/database.ts:345](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L345)

***

### addParticipant()

> `abstract` **addParticipant**(`entityId`, `roomId`): `Promise`\<`boolean`\>

Adds a user as a participant to a specific room.

#### Parameters

• **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the user to add as a participant.

• **roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the room to which the user will be added.

#### Returns

`Promise`\<`boolean`\>

A Promise that resolves to a boolean indicating success or failure.

#### Implementation of

`IDatabaseAdapter.addParticipant`

#### Defined in

[packages/core/src/database.ts:353](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L353)

***

### removeParticipant()

> `abstract` **removeParticipant**(`entityId`, `roomId`): `Promise`\<`boolean`\>

Removes a user as a participant from a specific room.

#### Parameters

• **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the user to remove as a participant.

• **roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the room from which the user will be removed.

#### Returns

`Promise`\<`boolean`\>

A Promise that resolves to a boolean indicating success or failure.

#### Implementation of

`IDatabaseAdapter.removeParticipant`

#### Defined in

[packages/core/src/database.ts:361](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L361)

***

### getParticipantsForEntity()

> `abstract` **getParticipantsForEntity**(`entityId`): `Promise`\<[`Participant`](../interfaces/Participant.md)[]\>

Retrieves participants associated with a specific account.

#### Parameters

• **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the account.

#### Returns

`Promise`\<[`Participant`](../interfaces/Participant.md)[]\>

A Promise that resolves to an array of Participant objects.

#### Implementation of

`IDatabaseAdapter.getParticipantsForEntity`

#### Defined in

[packages/core/src/database.ts:368](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L368)

***

### getParticipantsForRoom()

> `abstract` **getParticipantsForRoom**(`roomId`): `Promise`\<\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`[]\>

Retrieves participants for a specific room.

#### Parameters

• **roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the room for which to retrieve participants.

#### Returns

`Promise`\<\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`[]\>

A Promise that resolves to an array of UUIDs representing the participants.

#### Implementation of

`IDatabaseAdapter.getParticipantsForRoom`

#### Defined in

[packages/core/src/database.ts:375](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L375)

***

### createRelationship()

> `abstract` **createRelationship**(`params`): `Promise`\<`boolean`\>

Creates a new relationship between two users.

#### Parameters

• **params**

Object containing the relationship details including entity IDs, agent ID, optional tags and metadata

• **params.sourceEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.targetEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.tags?**: `string`[]

• **params.metadata?**: `Record`\<`string`, `unknown`\>

#### Returns

`Promise`\<`boolean`\>

A Promise that resolves to a boolean indicating success or failure of the creation.

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`createRelationship`](../interfaces/IDatabaseAdapter.md#createRelationship)

#### Defined in

[packages/core/src/database.ts:393](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L393)

***

### getRelationship()

> `abstract` **getRelationship**(`params`): `Promise`\<[`Relationship`](../interfaces/Relationship.md)\>

Retrieves a relationship between two users if it exists.

#### Parameters

• **params**

Object containing the entity IDs and agent ID

• **params.sourceEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.targetEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

#### Returns

`Promise`\<[`Relationship`](../interfaces/Relationship.md)\>

A Promise that resolves to the Relationship object or null if not found.

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`getRelationship`](../interfaces/IDatabaseAdapter.md#getRelationship)

#### Defined in

[packages/core/src/database.ts:405](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L405)

***

### getRelationships()

> `abstract` **getRelationships**(`params`): `Promise`\<[`Relationship`](../interfaces/Relationship.md)[]\>

Retrieves all relationships for a specific user.

#### Parameters

• **params**

Object containing the user ID, agent ID and optional tags to filter by

• **params.entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.tags?**: `string`[]

#### Returns

`Promise`\<[`Relationship`](../interfaces/Relationship.md)[]\>

A Promise that resolves to an array of Relationship objects.

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`getRelationships`](../interfaces/IDatabaseAdapter.md#getRelationships)

#### Defined in

[packages/core/src/database.ts:415](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L415)

***

### updateRelationship()

> `abstract` **updateRelationship**(`params`): `Promise`\<`void`\>

Updates an existing relationship between two users.

#### Parameters

• **params**

Object containing the relationship details to update including entity IDs, agent ID, optional tags and metadata

• **params.sourceEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.targetEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.tags?**: `string`[]

• **params.metadata?**: `Record`\<`string`, `unknown`\>

#### Returns

`Promise`\<`void`\>

A Promise that resolves to a boolean indicating success or failure of the update.

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`updateRelationship`](../interfaces/IDatabaseAdapter.md#updateRelationship)

#### Defined in

[packages/core/src/database.ts:422](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L422)

***

### getAgent()

> `abstract` **getAgent**(`agentId`): `Promise`\<`Agent`\>

Retrieves an agent by its ID.

#### Parameters

• **agentId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the agent to retrieve.

#### Returns

`Promise`\<`Agent`\>

A Promise that resolves to the Agent object or null if not found.

#### Implementation of

`IDatabaseAdapter.getAgent`

#### Defined in

[packages/core/src/database.ts:434](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L434)

***

### getAgents()

> `abstract` **getAgents**(): `Promise`\<`Agent`[]\>

Retrieves all agents from the database.

#### Returns

`Promise`\<`Agent`[]\>

A Promise that resolves to an array of Agent objects.

#### Implementation of

[`IDatabaseAdapter`](../interfaces/IDatabaseAdapter.md).[`getAgents`](../interfaces/IDatabaseAdapter.md#getAgents)

#### Defined in

[packages/core/src/database.ts:440](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L440)

***

### createAgent()

> `abstract` **createAgent**(`agent`): `Promise`\<`boolean`\>

Creates a new agent in the database.

#### Parameters

• **agent**: `Partial`\<`Agent`\>

The agent object to create.

#### Returns

`Promise`\<`boolean`\>

A Promise that resolves to a boolean indicating success or failure of the creation.

#### Implementation of

`IDatabaseAdapter.createAgent`

#### Defined in

[packages/core/src/database.ts:447](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L447)

***

### updateAgent()

> `abstract` **updateAgent**(`agentId`, `agent`): `Promise`\<`boolean`\>

Updates an existing agent in the database.

#### Parameters

• **agentId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the agent to update.

• **agent**: `Partial`\<`Agent`\>

The agent object with updated properties.

#### Returns

`Promise`\<`boolean`\>

A Promise that resolves to a boolean indicating success or failure of the update.

#### Implementation of

`IDatabaseAdapter.updateAgent`

#### Defined in

[packages/core/src/database.ts:455](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L455)

***

### deleteAgent()

> `abstract` **deleteAgent**(`agentId`): `Promise`\<`boolean`\>

Deletes an agent from the database.

#### Parameters

• **agentId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the agent to delete.

#### Returns

`Promise`\<`boolean`\>

A Promise that resolves to a boolean indicating success or failure of the deletion.

#### Implementation of

`IDatabaseAdapter.deleteAgent`

#### Defined in

[packages/core/src/database.ts:462](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L462)

***

### ensureAgentExists()

> `abstract` **ensureAgentExists**(`agent`): `Promise`\<`void`\>

Ensures an agent exists in the database.

#### Parameters

• **agent**: `Partial`\<`Agent`\>

The agent object to ensure exists.

#### Returns

`Promise`\<`void`\>

A Promise that resolves when the agent has been ensured to exist.

#### Implementation of

`IDatabaseAdapter.ensureAgentExists`

#### Defined in

[packages/core/src/database.ts:469](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L469)

***

### ensureEmbeddingDimension()

> `abstract` **ensureEmbeddingDimension**(`dimension`): `Promise`\<`void`\>

Ensures an embedding dimension exists in the database.

#### Parameters

• **dimension**: `number`

The dimension to ensure exists.

#### Returns

`Promise`\<`void`\>

A Promise that resolves when the embedding dimension has been ensured to exist.

#### Implementation of

`IDatabaseAdapter.ensureEmbeddingDimension`

#### Defined in

[packages/core/src/database.ts:476](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L476)

***

### getCache()

> `abstract` **getCache**\<`T`\>(`key`): `Promise`\<`T`\>

Retrieves a cached value by key from the database.

#### Type Parameters

• **T**

#### Parameters

• **key**: `string`

The key to look up in the cache

#### Returns

`Promise`\<`T`\>

Promise resolving to the cached string value

#### Implementation of

`IDatabaseAdapter.getCache`

#### Defined in

[packages/core/src/database.ts:483](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L483)

***

### setCache()

> `abstract` **setCache**\<`T`\>(`key`, `value`): `Promise`\<`boolean`\>

Sets a value in the cache with the given key.

#### Type Parameters

• **T**

#### Parameters

• **key**: `string`

The key to store the value under

• **value**: `T`

The string value to cache

#### Returns

`Promise`\<`boolean`\>

Promise resolving to true if the cache was set successfully

#### Implementation of

`IDatabaseAdapter.setCache`

#### Defined in

[packages/core/src/database.ts:492](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L492)

***

### deleteCache()

> `abstract` **deleteCache**(`key`): `Promise`\<`boolean`\>

Deletes a value from the cache by key.

#### Parameters

• **key**: `string`

The key to delete from the cache

#### Returns

`Promise`\<`boolean`\>

Promise resolving to true if the value was successfully deleted

#### Implementation of

`IDatabaseAdapter.deleteCache`

#### Defined in

[packages/core/src/database.ts:499](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L499)

***

### createTask()

> `abstract` **createTask**(`task`): `Promise`\<\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`\>

Creates a new task instance in the database.

#### Parameters

• **task**: `Task`

The task object to create

#### Returns

`Promise`\<\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`\>

Promise resolving to the UUID of the created task

#### Implementation of

`IDatabaseAdapter.createTask`

#### Defined in

[packages/core/src/database.ts:506](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L506)

***

### getTasks()

> `abstract` **getTasks**(`params`): `Promise`\<`Task`[]\>

Retrieves tasks based on specified parameters.

#### Parameters

• **params**

Object containing optional roomId and tags to filter tasks

• **params.roomId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.tags?**: `string`[]

#### Returns

`Promise`\<`Task`[]\>

Promise resolving to an array of Task objects

#### Implementation of

`IDatabaseAdapter.getTasks`

#### Defined in

[packages/core/src/database.ts:513](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L513)

***

### getTask()

> `abstract` **getTask**(`id`): `Promise`\<`Task`\>

Retrieves a specific task by its ID.

#### Parameters

• **id**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the task to retrieve

#### Returns

`Promise`\<`Task`\>

Promise resolving to the Task object if found, null otherwise

#### Implementation of

`IDatabaseAdapter.getTask`

#### Defined in

[packages/core/src/database.ts:520](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L520)

***

### getTasksByName()

> `abstract` **getTasksByName**(`name`): `Promise`\<`Task`[]\>

Retrieves a specific task by its name.

#### Parameters

• **name**: `string`

The name of the task to retrieve

#### Returns

`Promise`\<`Task`[]\>

Promise resolving to the Task object if found, null otherwise

#### Implementation of

`IDatabaseAdapter.getTasksByName`

#### Defined in

[packages/core/src/database.ts:527](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L527)

***

### updateTask()

> `abstract` **updateTask**(`id`, `task`): `Promise`\<`void`\>

Updates an existing task in the database.

#### Parameters

• **id**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the task to update

• **task**: `Partial`\<`Task`\>

Partial Task object containing the fields to update

#### Returns

`Promise`\<`void`\>

Promise resolving when the update is complete

#### Implementation of

`IDatabaseAdapter.updateTask`

#### Defined in

[packages/core/src/database.ts:535](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L535)

***

### deleteTask()

> `abstract` **deleteTask**(`id`): `Promise`\<`void`\>

Deletes a task from the database.

#### Parameters

• **id**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID of the task to delete

#### Returns

`Promise`\<`void`\>

Promise resolving when the deletion is complete

#### Implementation of

`IDatabaseAdapter.deleteTask`

#### Defined in

[packages/core/src/database.ts:542](https://github.com/elizaOS/eliza/blob/main/packages/core/src/database.ts#L542)
