[@elizaos/core v1.0.0-beta.32](../index.md) / AgentRuntime

# Class: AgentRuntime

Represents the runtime environment for an agent.

## Implements

## Implements

- `IAgentRuntime`

## Accessors

### db

#### Get Signature

> **get** **db**(): `any`

Database instance

##### Returns

`any`

#### Implementation of

`IAgentRuntime.db`

#### Defined in

[packages/core/src/runtime.ts:1467](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1467)

## Methods

### registerPlugin()

> **registerPlugin**(`plugin`): `Promise`\<`void`\>

Registers a plugin with the runtime and initializes its components

#### Parameters

• **plugin**: [`Plugin`](../interfaces/Plugin.md)

The plugin to register

#### Returns

`Promise`\<`void`\>

#### Implementation of

`IAgentRuntime.registerPlugin`

#### Defined in

[packages/core/src/runtime.ts:189](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L189)

***

### getConversationLength()

> **getConversationLength**(): `number`

Get the number of messages that are kept in the conversation buffer.

#### Returns

`number`

The number of recent messages to be kept in memory.

#### Implementation of

`IAgentRuntime.getConversationLength`

#### Defined in

[packages/core/src/runtime.ts:644](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L644)

***

### registerProvider()

> **registerProvider**(`provider`): `void`

Register a provider for the agent to use.

#### Parameters

• **provider**: [`Provider`](../interfaces/Provider.md)

The provider to register.

#### Returns

`void`

#### Implementation of

`IAgentRuntime.registerProvider`

#### Defined in

[packages/core/src/runtime.ts:663](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L663)

***

### registerAction()

> **registerAction**(`action`): `void`

Register an action for the agent to perform.

#### Parameters

• **action**: [`Action`](../interfaces/Action.md)

The action to register.

#### Returns

`void`

#### Implementation of

`IAgentRuntime.registerAction`

#### Defined in

[packages/core/src/runtime.ts:672](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L672)

***

### registerEvaluator()

> **registerEvaluator**(`evaluator`): `void`

Register an evaluator to assess and guide the agent's responses.

#### Parameters

• **evaluator**: [`Evaluator`](../interfaces/Evaluator.md)

The evaluator to register.

#### Returns

`void`

#### Implementation of

`IAgentRuntime.registerEvaluator`

#### Defined in

[packages/core/src/runtime.ts:693](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L693)

***

### registerContextProvider()

> **registerContextProvider**(`provider`): `void`

Register a context provider to provide context for message generation.

#### Parameters

• **provider**: [`Provider`](../interfaces/Provider.md)

The context provider to register.

#### Returns

`void`

#### Defined in

[packages/core/src/runtime.ts:701](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L701)

***

### processActions()

> **processActions**(`message`, `responses`, `state`?, `callback`?): `Promise`\<`void`\>

Process the actions of a message.

#### Parameters

• **message**: [`Memory`](../interfaces/Memory.md)

The message to process.

• **responses**: [`Memory`](../interfaces/Memory.md)[]

The array of response memories to process actions from.

• **state?**: [`State`](../interfaces/State.md)

Optional state object for the action processing.

• **callback?**: [`HandlerCallback`](../type-aliases/HandlerCallback.md)

Optional callback handler for action results.

#### Returns

`Promise`\<`void`\>

#### Implementation of

`IAgentRuntime.processActions`

#### Defined in

[packages/core/src/runtime.ts:712](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L712)

***

### evaluate()

> **evaluate**(`message`, `state`, `didRespond`?, `callback`?, `responses`?): `Promise`\<[`Evaluator`](../interfaces/Evaluator.md)[]\>

Evaluate the message and state using the registered evaluators.

#### Parameters

• **message**: [`Memory`](../interfaces/Memory.md)

The message to evaluate.

• **state**: [`State`](../interfaces/State.md)

The state of the agent.

• **didRespond?**: `boolean`

Whether the agent responded to the message.~

• **callback?**: [`HandlerCallback`](../type-aliases/HandlerCallback.md)

The handler callback

• **responses?**: [`Memory`](../interfaces/Memory.md)[]

#### Returns

`Promise`\<[`Evaluator`](../interfaces/Evaluator.md)[]\>

The results of the evaluation.

#### Implementation of

`IAgentRuntime.evaluate`

#### Defined in

[packages/core/src/runtime.ts:808](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L808)

***

### ensureParticipantInRoom()

> **ensureParticipantInRoom**(`entityId`, `roomId`): `Promise`\<`void`\>

Ensures a participant is added to a room, checking that the entity exists first

#### Parameters

• **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

#### Returns

`Promise`\<`void`\>

#### Implementation of

`IAgentRuntime.ensureParticipantInRoom`

#### Defined in

[packages/core/src/runtime.ts:1011](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1011)

***

### ensureWorldExists()

> **ensureWorldExists**(`__namedParameters`): `Promise`\<`void`\>

Ensure the existence of a world.

#### Parameters

• **\_\_namedParameters**: `World`

#### Returns

`Promise`\<`void`\>

#### Implementation of

`IAgentRuntime.ensureWorldExists`

#### Defined in

[packages/core/src/runtime.ts:1066](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1066)

***

### ensureRoomExists()

> **ensureRoomExists**(`entityId`): `Promise`\<`void`\>

Ensure the existence of a room between the agent and a user. If no room exists, a new room is created and the user
and agent are added as participants. The room ID is returned.

#### Parameters

• **entityId**: `Room`

The user ID to create a room with.

#### Returns

`Promise`\<`void`\>

The room ID of the room between the agent and the user.

#### Throws

An error if the room cannot be created.

#### Implementation of

`IAgentRuntime.ensureRoomExists`

#### Defined in

[packages/core/src/runtime.ts:1102](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1102)

***

### composeState()

> **composeState**(`message`, `filterList`, `includeList`): `Promise`\<[`State`](../interfaces/State.md)\>

Composes the agent's state by gathering data from enabled providers.

#### Parameters

• **message**: [`Memory`](../interfaces/Memory.md)

The message to use as context for state composition

• **filterList**: `string`[] = `null`

Optional list of provider names to include, filtering out all others

• **includeList**: `string`[] = `null`

Optional list of private provider names to include that would otherwise be filtered out

#### Returns

`Promise`\<[`State`](../interfaces/State.md)\>

A State object containing provider data, values, and text

#### Implementation of

`IAgentRuntime.composeState`

#### Defined in

[packages/core/src/runtime.ts:1127](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1127)

***

### useModel()

> **useModel**\<`T`, `R`\>(`modelType`, `params`): `Promise`\<`R`\>

Use a model with strongly typed parameters and return values based on model type

#### Type Parameters

• **T** *extends* `string`

The model type to use

• **R** = [`ModelResultMap`](../interfaces/ModelResultMap.md)\[`T`\]

The expected return type, defaults to the type defined in ModelResultMap[T]

#### Parameters

• **modelType**: `T`

The type of model to use

• **params**: `any`

The parameters for the model, typed based on model type

#### Returns

`Promise`\<`R`\>

- The model result, typed based on the provided generic type parameter

#### Implementation of

`IAgentRuntime.useModel`

#### Defined in

[packages/core/src/runtime.ts:1302](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1302)

***

### getTaskWorker()

> **getTaskWorker**(`name`): `TaskWorker`

Get a task worker by name

#### Parameters

• **name**: `string`

#### Returns

`TaskWorker`

#### Implementation of

`IAgentRuntime.getTaskWorker`

#### Defined in

[packages/core/src/runtime.ts:1461](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1461)

***

### init()

> **init**(): `Promise`\<`void`\>

Initialize database connection

#### Returns

`Promise`\<`void`\>

#### Implementation of

`IAgentRuntime.init`

#### Defined in

[packages/core/src/runtime.ts:1471](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1471)

***

### close()

> **close**(): `Promise`\<`void`\>

Close database connection

#### Returns

`Promise`\<`void`\>

#### Implementation of

`IAgentRuntime.close`

#### Defined in

[packages/core/src/runtime.ts:1475](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1475)

***

### getAgents()

> **getAgents**(): `Promise`\<`Agent`[]\>

Get all agents

#### Returns

`Promise`\<`Agent`[]\>

#### Implementation of

`IAgentRuntime.getAgents`

#### Defined in

[packages/core/src/runtime.ts:1483](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1483)

***

### getEntityById()

> **getEntityById**(`entityId`): `Promise`\<[`Entity`](../interfaces/Entity.md)\>

Get entity by ID

#### Parameters

• **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

#### Returns

`Promise`\<[`Entity`](../interfaces/Entity.md)\>

#### Implementation of

`IAgentRuntime.getEntityById`

#### Defined in

[packages/core/src/runtime.ts:1503](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1503)

***

### getEntitiesForRoom()

> **getEntitiesForRoom**(`roomId`, `includeComponents`?): `Promise`\<[`Entity`](../interfaces/Entity.md)[]\>

Get entities for room

#### Parameters

• **roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **includeComponents?**: `boolean`

#### Returns

`Promise`\<[`Entity`](../interfaces/Entity.md)[]\>

#### Implementation of

`IAgentRuntime.getEntitiesForRoom`

#### Defined in

[packages/core/src/runtime.ts:1507](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1507)

***

### createEntity()

> **createEntity**(`entity`): `Promise`\<`boolean`\>

Create new entity

#### Parameters

• **entity**: [`Entity`](../interfaces/Entity.md)

#### Returns

`Promise`\<`boolean`\>

#### Implementation of

`IAgentRuntime.createEntity`

#### Defined in

[packages/core/src/runtime.ts:1511](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1511)

***

### updateEntity()

> **updateEntity**(`entity`): `Promise`\<`void`\>

Update entity

#### Parameters

• **entity**: [`Entity`](../interfaces/Entity.md)

#### Returns

`Promise`\<`void`\>

#### Implementation of

`IAgentRuntime.updateEntity`

#### Defined in

[packages/core/src/runtime.ts:1518](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1518)

***

### getComponent()

> **getComponent**(`entityId`, `type`, `worldId`?, `sourceEntityId`?): `Promise`\<`Component`\>

Get component by ID

#### Parameters

• **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **type**: `string`

• **worldId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **sourceEntityId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

#### Returns

`Promise`\<`Component`\>

#### Implementation of

`IAgentRuntime.getComponent`

#### Defined in

[packages/core/src/runtime.ts:1522](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1522)

***

### getComponents()

> **getComponents**(`entityId`, `worldId`?, `sourceEntityId`?): `Promise`\<`Component`[]\>

Get all components for an entity

#### Parameters

• **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **worldId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **sourceEntityId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

#### Returns

`Promise`\<`Component`[]\>

#### Implementation of

`IAgentRuntime.getComponents`

#### Defined in

[packages/core/src/runtime.ts:1531](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1531)

***

### createComponent()

> **createComponent**(`component`): `Promise`\<`boolean`\>

Create component

#### Parameters

• **component**: `Component`

#### Returns

`Promise`\<`boolean`\>

#### Implementation of

`IAgentRuntime.createComponent`

#### Defined in

[packages/core/src/runtime.ts:1535](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1535)

***

### updateComponent()

> **updateComponent**(`component`): `Promise`\<`void`\>

Update component

#### Parameters

• **component**: `Component`

#### Returns

`Promise`\<`void`\>

#### Implementation of

`IAgentRuntime.updateComponent`

#### Defined in

[packages/core/src/runtime.ts:1539](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1539)

***

### deleteComponent()

> **deleteComponent**(`componentId`): `Promise`\<`void`\>

Delete component

#### Parameters

• **componentId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

#### Returns

`Promise`\<`void`\>

#### Implementation of

`IAgentRuntime.deleteComponent`

#### Defined in

[packages/core/src/runtime.ts:1543](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1543)

***

### getMemories()

> **getMemories**(`params`): `Promise`\<[`Memory`](../interfaces/Memory.md)[]\>

Get memories matching criteria

#### Parameters

• **params**

• **params.entityId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.agentId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.roomId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.count?**: `number`

• **params.unique?**: `boolean`

• **params.tableName**: `string`

• **params.start?**: `number`

• **params.end?**: `number`

#### Returns

`Promise`\<[`Memory`](../interfaces/Memory.md)[]\>

#### Implementation of

`IAgentRuntime.getMemories`

#### Defined in

[packages/core/src/runtime.ts:1574](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1574)

***

### createRelationship()

> **createRelationship**(`params`): `Promise`\<`boolean`\>

Creates a new relationship between two entities.

#### Parameters

• **params**

Object containing the relationship details

• **params.sourceEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.targetEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.tags?**: `string`[]

• **params.metadata?**

#### Returns

`Promise`\<`boolean`\>

Promise resolving to boolean indicating success

#### Implementation of

`IAgentRuntime.createRelationship`

#### Defined in

[packages/core/src/runtime.ts:1737](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1737)

***

### updateRelationship()

> **updateRelationship**(`relationship`): `Promise`\<`void`\>

Updates an existing relationship between two entities.

#### Parameters

• **relationship**: [`Relationship`](../interfaces/Relationship.md)

The relationship object with updated data

#### Returns

`Promise`\<`void`\>

Promise resolving to void

#### Implementation of

`IAgentRuntime.updateRelationship`

#### Defined in

[packages/core/src/runtime.ts:1746](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1746)

***

### getRelationship()

> **getRelationship**(`params`): `Promise`\<[`Relationship`](../interfaces/Relationship.md)\>

Retrieves a relationship between two entities if it exists.

#### Parameters

• **params**

Object containing the entity IDs and agent ID

• **params.sourceEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.targetEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

#### Returns

`Promise`\<[`Relationship`](../interfaces/Relationship.md)\>

Promise resolving to the Relationship object or null if not found

#### Implementation of

`IAgentRuntime.getRelationship`

#### Defined in

[packages/core/src/runtime.ts:1750](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1750)

***

### getRelationships()

> **getRelationships**(`params`): `Promise`\<[`Relationship`](../interfaces/Relationship.md)[]\>

Retrieves all relationships for a specific entity.

#### Parameters

• **params**

Object containing the user ID, agent ID and optional tags to filter by

• **params.entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.tags?**: `string`[]

#### Returns

`Promise`\<[`Relationship`](../interfaces/Relationship.md)[]\>

Promise resolving to an array of Relationship objects

#### Implementation of

`IAgentRuntime.getRelationships`

#### Defined in

[packages/core/src/runtime.ts:1757](https://github.com/elizaOS/eliza/blob/main/packages/core/src/runtime.ts#L1757)
