[@elizaos/core v1.0.0-beta.32](../index.md) / Service

# Class: `abstract` Service

Client instance

## Extended by

- [`TypedService`](../interfaces/TypedService.md)

## Properties

### runtime

> `protected` **runtime**: `IAgentRuntime`

Runtime instance

#### Defined in

[packages/core/src/types.ts:519](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L519)

***

### serviceType

> `static` **serviceType**: `string`

Service type

#### Defined in

[packages/core/src/types.ts:530](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L530)

***

### capabilityDescription

> `abstract` **capabilityDescription**: `string`

Service name

#### Defined in

[packages/core/src/types.ts:533](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L533)

***

### config?

> `optional` **config**: `object`

Service configuration

#### Index Signature

 \[`key`: `string`\]: `any`

#### Defined in

[packages/core/src/types.ts:536](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L536)

## Methods

### start()

> `static` **start**(`_runtime`): `Promise`\<[`Service`](Service.md)\>

Start service connection

#### Parameters

• **\_runtime**: `IAgentRuntime`

#### Returns

`Promise`\<[`Service`](Service.md)\>

#### Defined in

[packages/core/src/types.ts:539](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L539)

***

### stop()

> `static` **stop**(`_runtime`): `Promise`\<`unknown`\>

Stop service connection

#### Parameters

• **\_runtime**: `IAgentRuntime`

#### Returns

`Promise`\<`unknown`\>

#### Defined in

[packages/core/src/types.ts:544](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L544)
