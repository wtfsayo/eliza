[@elizaos/core v1.0.0-beta.32](../index.md) / createSettingFromConfig

# Function: createSettingFromConfig()

> **createSettingFromConfig**(`configSetting`): `Setting`

Creates a Setting object from a configSetting object by omitting the 'value' property.

## Parameters

• **configSetting**: `Omit`\<`Setting`, `"value"`\>

The configSetting object to create the Setting from.

## Returns

`Setting`

A new Setting object created from the provided configSetting object.

## Defined in

[packages/core/src/settings.ts:24](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L24)
