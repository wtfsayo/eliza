[@elizaos/core v1.0.0-beta.32](../index.md) / initializeOnboarding

# Function: initializeOnboarding()

> **initializeOnboarding**(`runtime`, `world`, `config`): `Promise`\<`WorldSettings`\>

Initializes settings configuration for a server

## Parameters

• **runtime**: `IAgentRuntime`

• **world**: `World`

• **config**: `OnboardingConfig`

## Returns

`Promise`\<`WorldSettings`\>

## Defined in

[packages/core/src/settings.ts:292](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L292)
