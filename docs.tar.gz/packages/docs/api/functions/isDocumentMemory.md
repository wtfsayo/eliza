[@elizaos/core v1.0.0-beta.32](../index.md) / isDocumentMemory

# Function: isDocumentMemory()

> **isDocumentMemory**(`memory`): `memory is Memory & { metadata: DocumentMetadata }`

Memory type guard for document memories

## Parameters

• **memory**: [`Memory`](../interfaces/Memory.md)

## Returns

`memory is Memory & { metadata: DocumentMetadata }`

## Defined in

[packages/core/src/types.ts:1854](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1854)
