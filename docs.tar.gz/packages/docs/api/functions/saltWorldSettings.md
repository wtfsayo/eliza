[@elizaos/core v1.0.0-beta.32](../index.md) / saltWorldSettings

# Function: saltWorldSettings()

> **saltWorldSettings**(`worldSettings`, `salt`): `WorldSettings`

Applies salt to all settings in a WorldSettings object

## Parameters

• **worldSettings**: `WorldSettings`

• **salt**: `string`

## Returns

`WorldSettings`

## Defined in

[packages/core/src/settings.ts:200](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L200)
