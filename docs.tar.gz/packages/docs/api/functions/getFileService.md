[@elizaos/core v1.0.0-beta.32](../index.md) / getFileService

# Function: getFileService()

> **getFileService**(`runtime`): `IFileService`

Type-safe helper for accessing the file service

## Parameters

• **runtime**: `IAgentRuntime`

## Returns

`IFileService`

## Defined in

[packages/core/src/types.ts:1847](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1847)
