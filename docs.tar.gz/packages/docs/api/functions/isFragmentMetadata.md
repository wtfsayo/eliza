[@elizaos/core v1.0.0-beta.32](../index.md) / isFragmentMetadata

# Function: isFragmentMetadata()

> **isFragmentMetadata**(`metadata`): `metadata is FragmentMetadata`

Type guard to check if a memory metadata is a FragmentMetadata

## Parameters

• **metadata**: `MemoryMetadata`

The metadata to check

## Returns

`metadata is FragmentMetadata`

True if the metadata is a FragmentMetadata

## Defined in

[packages/core/src/types.ts:1777](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1777)
