[@elizaos/core v1.0.0-beta.32](../index.md) / getPdfService

# Function: getPdfService()

> **getPdfService**(`runtime`): `IPdfService`

Type-safe helper for accessing the PDF service

## Parameters

• **runtime**: `IAgentRuntime`

## Returns

`IPdfService`

## Defined in

[packages/core/src/types.ts:1840](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1840)
