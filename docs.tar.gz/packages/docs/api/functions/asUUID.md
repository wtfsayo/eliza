[@elizaos/core v1.0.0-beta.32](../index.md) / asUUID

# Function: asUUID()

> **asUUID**(`id`): \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Helper function to safely cast a string to strongly typed UUID

## Parameters

• **id**: `string`

The string UUID to validate and cast

## Returns

\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The same UUID with branded type information

## Defined in

[packages/core/src/types.ts:15](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L15)
