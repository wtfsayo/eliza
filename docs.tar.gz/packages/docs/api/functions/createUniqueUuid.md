[@elizaos/core v1.0.0-beta.32](../index.md) / createUniqueUuid

# Function: createUniqueUuid()

> **createUniqueUuid**(`runtime`, `baseUserId`): \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Function to create a unique UUID based on the runtime and base user ID.

## Parameters

• **runtime**: `any`

The runtime context object.

• **baseUserId**: `string`

The base user ID to use in generating the UUID.

## Returns

\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

- The unique UUID generated based on the runtime and base user ID.

## Defined in

[packages/core/src/entities.ts:300](https://github.com/elizaOS/eliza/blob/main/packages/core/src/entities.ts#L300)
