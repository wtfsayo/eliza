[@elizaos/core v1.0.0-beta.32](../index.md) / decryptObjectValues

# Function: decryptObjectValues()

> **decryptObjectValues**(`obj`, `salt`): `Record`\<`string`, `any`\>

Helper function to decrypt all string values in an object

## Parameters

• **obj**: `Record`\<`string`, `any`\>

Object with encrypted values

• **salt**: `string`

The salt to use for decryption

## Returns

`Record`\<`string`, `any`\>

- Object with decrypted values

## Defined in

[packages/core/src/settings.ts:409](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L409)
