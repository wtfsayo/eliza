[@elizaos/core v1.0.0-beta.32](../index.md) / getWorldSettings

# Function: getWorldSettings()

> **getWorldSettings**(`runtime`, `serverId`): `Promise`\<`WorldSettings`\>

Gets settings state from world metadata

## Parameters

• **runtime**: `IAgentRuntime`

• **serverId**: `string`

## Returns

`Promise`\<`WorldSettings`\>

## Defined in

[packages/core/src/settings.ts:265](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L265)
