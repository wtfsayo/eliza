[@elizaos/core v1.0.0-beta.32](../index.md) / parseBooleanFromText

# Function: parseBooleanFromText()

> **parseBooleanFromText**(`value`): `boolean`

Parses a string to determine its boolean equivalent.

Recognized affirmative values: "YES", "Y", "TRUE", "T", "1", "ON", "ENABLE"
Recognized negative values: "NO", "N", "FALSE", "F", "0", "OFF", "DISABLE"

## Parameters

• **value**: `string`

The input text to parse

## Returns

`boolean`

- Returns `true` for affirmative inputs, `false` for negative or unrecognized inputs

## Defined in

[packages/core/src/prompts.ts:390](https://github.com/elizaOS/eliza/blob/main/packages/core/src/prompts.ts#L390)
