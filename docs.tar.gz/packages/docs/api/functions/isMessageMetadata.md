[@elizaos/core v1.0.0-beta.32](../index.md) / isMessageMetadata

# Function: isMessageMetadata()

> **isMessageMetadata**(`metadata`): `metadata is MessageMetadata`

Type guard to check if a memory metadata is a MessageMetadata

## Parameters

• **metadata**: `MemoryMetadata`

The metadata to check

## Returns

`metadata is MessageMetadata`

True if the metadata is a MessageMetadata

## Defined in

[packages/core/src/types.ts:1786](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1786)
