[@elizaos/core v1.0.0-beta.32](../index.md) / decryptStringValue

# Function: decryptStringValue()

> **decryptStringValue**(`value`, `salt`): `string`

Common decryption function for string values

## Parameters

• **value**: `string`

The encrypted value in 'iv:encrypted' format

• **salt**: `string`

The salt to use for decryption

## Returns

`string`

- The decrypted string value

## Defined in

[packages/core/src/settings.ts:120](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L120)
