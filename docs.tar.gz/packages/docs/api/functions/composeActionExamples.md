[@elizaos/core v1.0.0-beta.32](../index.md) / composeActionExamples

# Function: composeActionExamples()

> **composeActionExamples**(`actionsData`, `count`): `string`

Compose a specified number of random action examples from the given actionsData.

## Parameters

• **actionsData**: [`Action`](../interfaces/Action.md)[]

The list of actions to generate examples from.

• **count**: `number`

The number of examples to compose.

## Returns

`string`

The formatted action examples.

## Defined in

[packages/core/src/actions.ts:18](https://github.com/elizaOS/eliza/blob/main/packages/core/src/actions.ts#L18)
