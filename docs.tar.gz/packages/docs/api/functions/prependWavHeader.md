[@elizaos/core v1.0.0-beta.32](../index.md) / prependWavHeader

# Function: prependWavHeader()

> **prependWavHeader**(`readable`, `audioLength`, `sampleRate`, `channelCount`?, `bitsPerSample`?): `any`

Prepends a WAV header to a readable stream of audio data.

## Parameters

• **readable**: `any`

The readable stream containing the audio data.

• **audioLength**: `number`

The length of the audio data in seconds.

• **sampleRate**: `number`

The sample rate of the audio data.

• **channelCount?**: `number` = `1`

The number of channels in the audio data (default is 1).

• **bitsPerSample?**: `number` = `16`

The number of bits per sample in the audio data (default is 16).

## Returns

`any`

A new readable stream with the WAV header prepended to the audio data.

## Defined in

[packages/core/src/audioUtils.ts:46](https://github.com/elizaOS/eliza/blob/main/packages/core/src/audioUtils.ts#L46)
