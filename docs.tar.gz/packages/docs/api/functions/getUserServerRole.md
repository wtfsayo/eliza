[@elizaos/core v1.0.0-beta.32](../index.md) / getUserServerRole

# Function: getUserServerRole()

> **getUserServerRole**(`runtime`, `entityId`, `serverId`): `Promise`\<`Role`\>

Retrieve the server role of a specified user entity within a given server.

## Parameters

• **runtime**: `IAgentRuntime`

The runtime object containing necessary configurations and services.

• **entityId**: `string`

The unique identifier of the user entity.

• **serverId**: `string`

The unique identifier of the server.

## Returns

`Promise`\<`Role`\>

The role of the user entity within the server, resolved as a Promise.

## Defined in

[packages/core/src/roles.ts:32](https://github.com/elizaOS/eliza/blob/main/packages/core/src/roles.ts#L32)
