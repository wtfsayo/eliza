[@elizaos/core v1.0.0-beta.32](../index.md) / decryptedCharacter

# Function: decryptedCharacter()

> **decryptedCharacter**(`character`, `runtime`): [`Character`](../interfaces/Character.md)

Decrypts sensitive data in a Character object

## Parameters

• **character**: [`Character`](../interfaces/Character.md)

The character object with encrypted secrets

• **runtime**: `IAgentRuntime`

The runtime information needed for salt generation

## Returns

[`Character`](../interfaces/Character.md)

- A copy of the character with decrypted secrets

## Defined in

[packages/core/src/settings.ts:365](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L365)
