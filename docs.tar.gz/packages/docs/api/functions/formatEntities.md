[@elizaos/core v1.0.0-beta.32](../index.md) / formatEntities

# Function: formatEntities()

> **formatEntities**(`options`): `string`

Format the given entities into a string representation.

## Parameters

• **options**

The options object.

• **options.entities**: [`Entity`](../interfaces/Entity.md)[]

The list of entities to format.

## Returns

`string`

A formatted string representing the entities.

## Defined in

[packages/core/src/entities.ts:391](https://github.com/elizaOS/eliza/blob/main/packages/core/src/entities.ts#L391)
