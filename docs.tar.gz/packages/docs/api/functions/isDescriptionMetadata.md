[@elizaos/core v1.0.0-beta.32](../index.md) / isDescriptionMetadata

# Function: isDescriptionMetadata()

> **isDescriptionMetadata**(`metadata`): `metadata is DescriptionMetadata`

Type guard to check if a memory metadata is a DescriptionMetadata

## Parameters

• **metadata**: `MemoryMetadata`

The metadata to check

## Returns

`metadata is DescriptionMetadata`

True if the metadata is a DescriptionMetadata

## Defined in

[packages/core/src/types.ts:1795](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1795)
