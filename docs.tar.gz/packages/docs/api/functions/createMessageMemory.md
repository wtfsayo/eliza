[@elizaos/core v1.0.0-beta.32](../index.md) / createMessageMemory

# Function: createMessageMemory()

> **createMessageMemory**(`params`): [`MessageMemory`](../interfaces/MessageMemory.md)

Factory function to create a new message memory with proper defaults

## Parameters

• **params**

• **params.id?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.agentId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.content**: [`Content`](../interfaces/Content.md) & `object`

• **params.embedding?**: `number`[]

## Returns

[`MessageMemory`](../interfaces/MessageMemory.md)

## Defined in

[packages/core/src/types.ts:1712](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1712)
