[@elizaos/core v1.0.0-beta.32](../index.md) / getSalt

# Function: getSalt()

> **getSalt**(): `string`

Retrieves the salt based on env variable SECRET_SALT

## Returns

`string`

The salt for the agent.

## Defined in

[packages/core/src/settings.ts:45](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L45)
