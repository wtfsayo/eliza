[@elizaos/core v1.0.0-beta.32](../index.md) / composeRandomUser

# Function: composeRandomUser()

> **composeRandomUser**(`template`, `length`): `string`

Generates a string with random user names populated in a template.

This function generates random user names and populates placeholders
in the provided template with these names. Placeholders in the template should follow the format `{{userX}}`
where `X` is the position of the user (e.g., `{{name1}}`, `{{name2}}`).

## Parameters

• **template**: `string`

The template string containing placeholders for random user names.

• **length**: `number`

The number of random user names to generate.

## Returns

`string`

The template string with placeholders replaced by random user names.

## Example

```ts
// Given a template and a length
const template = "Hello, {{name1}}! Meet {{name2}} and {{name3}}.";
const length = 3;

// Composing the random user string will result in:
// "Hello, John! Meet Alice and Bob."
const result = composeRandomUser(template, length);
```

## Defined in

[packages/core/src/prompts.ts:131](https://github.com/elizaOS/eliza/blob/main/packages/core/src/prompts.ts#L131)
