[@elizaos/core v1.0.0-beta.32](../index.md) / getMemoryText

# Function: getMemoryText()

> **getMemoryText**(`memory`, `defaultValue`): `string`

Safely access the text content of a memory

## Parameters

• **memory**: [`Memory`](../interfaces/Memory.md)

The memory to extract text from

• **defaultValue**: `string` = `''`

Optional default value if no text is found

## Returns

`string`

The text content or default value

## Defined in

[packages/core/src/types.ts:1875](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1875)
