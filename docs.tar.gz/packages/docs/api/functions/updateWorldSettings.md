[@elizaos/core v1.0.0-beta.32](../index.md) / updateWorldSettings

# Function: updateWorldSettings()

> **updateWorldSettings**(`runtime`, `serverId`, `worldSettings`): `Promise`\<`boolean`\>

Updates settings state in world metadata

## Parameters

• **runtime**: `IAgentRuntime`

• **serverId**: `string`

• **worldSettings**: `WorldSettings`

## Returns

`Promise`\<`boolean`\>

## Defined in

[packages/core/src/settings.ts:226](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L226)
