[@elizaos/core v1.0.0-beta.32](../index.md) / isDocumentMetadata

# Function: isDocumentMetadata()

> **isDocumentMetadata**(`metadata`): `metadata is DocumentMetadata`

Type guard to check if a memory metadata is a DocumentMetadata

## Parameters

• **metadata**: `MemoryMetadata`

The metadata to check

## Returns

`metadata is DocumentMetadata`

True if the metadata is a DocumentMetadata

## Defined in

[packages/core/src/types.ts:1768](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1768)
