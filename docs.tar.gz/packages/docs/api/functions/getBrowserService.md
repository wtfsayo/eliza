[@elizaos/core v1.0.0-beta.32](../index.md) / getBrowserService

# Function: getBrowserService()

> **getBrowserService**(`runtime`): `IBrowserService`

Type-safe helper for accessing the browser service

## Parameters

• **runtime**: `IAgentRuntime`

## Returns

`IBrowserService`

## Defined in

[packages/core/src/types.ts:1833](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1833)
