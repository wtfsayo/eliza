[@elizaos/core v1.0.0-beta.32](../index.md) / findWorldsForOwner

# Function: findWorldsForOwner()

> **findWorldsForOwner**(`runtime`, `entityId`): `Promise`\<`World`[]\>

Finds a server where the given user is the owner

## Parameters

• **runtime**: `IAgentRuntime`

• **entityId**: `string`

## Returns

`Promise`\<`World`[]\>

## Defined in

[packages/core/src/roles.ts:64](https://github.com/elizaOS/eliza/blob/main/packages/core/src/roles.ts#L64)
