[@elizaos/core v1.0.0-beta.32](../index.md) / getTypedService

# Function: getTypedService()

> **getTypedService**\<`T`\>(`runtime`, `serviceType`): `T`

Generic factory function to create a typed service instance

## Type Parameters

• **T** *extends* [`TypedService`](../interfaces/TypedService.md)\<`any`, `any`\>

## Parameters

• **runtime**: `IAgentRuntime`

The agent runtime

• **serviceType**: `ServiceTypeName`

The type of service to get

## Returns

`T`

The service instance or null if not available

## Defined in

[packages/core/src/types.ts:1756](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1756)
