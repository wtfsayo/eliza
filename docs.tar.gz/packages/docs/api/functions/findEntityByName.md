[@elizaos/core v1.0.0-beta.32](../index.md) / findEntityByName

# Function: findEntityByName()

> **findEntityByName**(`runtime`, `message`, `state`): `Promise`\<[`Entity`](../interfaces/Entity.md)\>

Finds an entity by name in the given runtime environment.

## Parameters

• **runtime**: `IAgentRuntime`

The agent runtime environment.

• **message**: [`Memory`](../interfaces/Memory.md)

The memory message containing relevant information.

• **state**: [`State`](../interfaces/State.md)

The current state of the system.

## Returns

`Promise`\<[`Entity`](../interfaces/Entity.md)\>

A promise that resolves to the found entity or null if not found.

## Defined in

[packages/core/src/entities.ts:134](https://github.com/elizaOS/eliza/blob/main/packages/core/src/entities.ts#L134)
