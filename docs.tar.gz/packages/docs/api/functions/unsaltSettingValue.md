[@elizaos/core v1.0.0-beta.32](../index.md) / unsaltSettingValue

# Function: unsaltSettingValue()

> **unsaltSettingValue**(`setting`, `salt`): `Setting`

Removes salt from the value of a setting
Only applies to secret settings with string values

## Parameters

• **setting**: `Setting`

• **salt**: `string`

## Returns

`Setting`

## Defined in

[packages/core/src/settings.ts:186](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L186)
