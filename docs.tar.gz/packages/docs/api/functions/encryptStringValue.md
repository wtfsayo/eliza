[@elizaos/core v1.0.0-beta.32](../index.md) / encryptStringValue

# Function: encryptStringValue()

> **encryptStringValue**(`value`, `salt`): `string`

Common encryption function for string values

## Parameters

• **value**: `string`

The string value to encrypt

• **salt**: `string`

The salt to use for encryption

## Returns

`string`

- The encrypted value in 'iv:encrypted' format

## Defined in

[packages/core/src/settings.ts:67](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L67)
