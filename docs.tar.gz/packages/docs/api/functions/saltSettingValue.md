[@elizaos/core v1.0.0-beta.32](../index.md) / saltSettingValue

# Function: saltSettingValue()

> **saltSettingValue**(`setting`, `salt`): `Setting`

Applies salt to the value of a setting
Only applies to secret settings with string values

## Parameters

• **setting**: `Setting`

• **salt**: `string`

## Returns

`Setting`

## Defined in

[packages/core/src/settings.ts:171](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L171)
