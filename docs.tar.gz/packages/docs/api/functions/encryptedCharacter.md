[@elizaos/core v1.0.0-beta.32](../index.md) / encryptedCharacter

# Function: encryptedCharacter()

> **encryptedCharacter**(`character`): [`Character`](../interfaces/Character.md)

Encrypts sensitive data in a Character object

## Parameters

• **character**: [`Character`](../interfaces/Character.md)

The character object to encrypt secrets for

## Returns

[`Character`](../interfaces/Character.md)

- A copy of the character with encrypted secrets

## Defined in

[packages/core/src/settings.ts:341](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L341)
