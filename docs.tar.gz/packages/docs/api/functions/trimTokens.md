[@elizaos/core v1.0.0-beta.32](../index.md) / trimTokens

# Function: trimTokens()

> **trimTokens**(`prompt`, `maxTokens`, `runtime`): `Promise`\<`string`\>

Trims the provided text prompt to a specified token limit using a tokenizer model and type.

## Parameters

• **prompt**: `string`

• **maxTokens**: `number`

• **runtime**: `IAgentRuntime`

## Returns

`Promise`\<`string`\>

## Defined in

[packages/core/src/prompts.ts:683](https://github.com/elizaOS/eliza/blob/main/packages/core/src/prompts.ts#L683)
