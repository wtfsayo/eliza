[@elizaos/core v1.0.0-beta.32](../index.md) / cleanJsonResponse

# Function: cleanJsonResponse()

> **cleanJsonResponse**(`response`): `string`

Cleans a JSON-like response string by removing unnecessary markers, line breaks, and extra whitespace.
This is useful for handling improperly formatted JSON responses from external sources.

## Parameters

• **response**: `string`

The raw JSON-like string response to clean.

## Returns

`string`

The cleaned string, ready for parsing or further processing.

## Defined in

[packages/core/src/prompts.ts:576](https://github.com/elizaOS/eliza/blob/main/packages/core/src/prompts.ts#L576)
