[@elizaos/core v1.0.0-beta.32](../index.md) / isCustomMetadata

# Function: isCustomMetadata()

> **isCustomMetadata**(`metadata`): `metadata is CustomMetadata`

Type guard to check if a memory metadata is a CustomMetadata

## Parameters

• **metadata**: `MemoryMetadata`

The metadata to check

## Returns

`metadata is CustomMetadata`

True if the metadata is a CustomMetadata

## Defined in

[packages/core/src/types.ts:1804](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1804)
