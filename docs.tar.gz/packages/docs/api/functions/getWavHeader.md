[@elizaos/core v1.0.0-beta.32](../index.md) / getWavHeader

# Function: getWavHeader()

> **getWavHeader**(`audioLength`, `sampleRate`, `channelCount`?, `bitsPerSample`?): `Buffer`

Generates a WAV file header based on the provided audio parameters.

## Parameters

• **audioLength**: `number`

The length of the audio data in bytes.

• **sampleRate**: `number`

The sample rate of the audio.

• **channelCount?**: `number` = `1`

The number of channels (default is 1).

• **bitsPerSample?**: `number` = `16`

The number of bits per sample (default is 16).

## Returns

`Buffer`

The WAV file header as a Buffer object.

## Defined in

[packages/core/src/audioUtils.ts:13](https://github.com/elizaOS/eliza/blob/main/packages/core/src/audioUtils.ts#L13)
