[@elizaos/core v1.0.0-beta.32](../index.md) / getEntityDetails

# Function: getEntityDetails()

> **getEntityDetails**(`params`): `Promise`\<`any`[]\>

Retrieves entity details for a specific room from the database.

## Parameters

• **params**

The input parameters

• **params.runtime**: `IAgentRuntime`

The Agent Runtime instance

• **params.roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The ID of the room to retrieve entity details for

## Returns

`Promise`\<`any`[]\>

- A promise that resolves to an array of unique entity details

## Defined in

[packages/core/src/entities.ts:325](https://github.com/elizaOS/eliza/blob/main/packages/core/src/entities.ts#L325)
