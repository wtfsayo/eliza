[@elizaos/core v1.0.0-beta.32](../index.md) / createServiceError

# Function: createServiceError()

> **createServiceError**(`error`, `code`): [`ServiceError`](../interfaces/ServiceError.md)

Safely create a ServiceError from any caught error

## Parameters

• **error**: `unknown`

• **code**: `string` = `'UNKNOWN_ERROR'`

## Returns

[`ServiceError`](../interfaces/ServiceError.md)

## Defined in

[packages/core/src/types.ts:1882](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1882)
