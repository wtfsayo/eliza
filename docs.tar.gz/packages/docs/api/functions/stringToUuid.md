[@elizaos/core v1.0.0-beta.32](../index.md) / stringToUuid

# Function: stringToUuid()

> **stringToUuid**(`target`): \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Converts a string or number to a UUID.

## Parameters

• **target**: `string` \| `number`

The string or number to convert to a UUID.

## Returns

\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The UUID generated from the input target.

## Throws

Throws an error if the input target is not a string.

## Defined in

[packages/core/src/uuid.ts:31](https://github.com/elizaOS/eliza/blob/main/packages/core/src/uuid.ts#L31)
