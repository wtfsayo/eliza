[@elizaos/core v1.0.0-beta.32](../index.md) / getVideoService

# Function: getVideoService()

> **getVideoService**(`runtime`): `IVideoService`

Type-safe helper for accessing the video service

## Parameters

• **runtime**: `IAgentRuntime`

## Returns

`IVideoService`

## Defined in

[packages/core/src/types.ts:1826](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1826)
