[@elizaos/core v1.0.0-beta.32](../index.md) / composePromptFromState

# Function: composePromptFromState()

> **composePromptFromState**(`options`): `string`

Function to compose a prompt using a provided template and state.

## Parameters

• **options**

Object containing state and template information.

• **options.state**: [`State`](../interfaces/State.md)

The state object containing values to fill the template.

• **options.template**: `TemplateType`

The template to be used for composing the prompt.

## Returns

`string`

The composed prompt output.

## Defined in

[packages/core/src/prompts.ts:66](https://github.com/elizaOS/eliza/blob/main/packages/core/src/prompts.ts#L66)
