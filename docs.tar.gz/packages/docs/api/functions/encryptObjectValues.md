[@elizaos/core v1.0.0-beta.32](../index.md) / encryptObjectValues

# Function: encryptObjectValues()

> **encryptObjectValues**(`obj`, `salt`): `Record`\<`string`, `any`\>

Helper function to encrypt all string values in an object

## Parameters

• **obj**: `Record`\<`string`, `any`\>

Object with values to encrypt

• **salt**: `string`

The salt to use for encryption

## Returns

`Record`\<`string`, `any`\>

- Object with encrypted values

## Defined in

[packages/core/src/settings.ts:389](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L389)
