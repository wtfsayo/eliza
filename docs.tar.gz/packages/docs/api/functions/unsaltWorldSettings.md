[@elizaos/core v1.0.0-beta.32](../index.md) / unsaltWorldSettings

# Function: unsaltWorldSettings()

> **unsaltWorldSettings**(`worldSettings`, `salt`): `WorldSettings`

Removes salt from all settings in a WorldSettings object

## Parameters

• **worldSettings**: `WorldSettings`

• **salt**: `string`

## Returns

`WorldSettings`

## Defined in

[packages/core/src/settings.ts:213](https://github.com/elizaOS/eliza/blob/main/packages/core/src/settings.ts#L213)
