[@elizaos/core v1.0.0-beta.32](../index.md) / isFragmentMemory

# Function: isFragmentMemory()

> **isFragmentMemory**(`memory`): `memory is Memory & { metadata: FragmentMetadata }`

Memory type guard for fragment memories

## Parameters

• **memory**: [`Memory`](../interfaces/Memory.md)

## Returns

`memory is Memory & { metadata: FragmentMetadata }`

## Defined in

[packages/core/src/types.ts:1863](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1863)
