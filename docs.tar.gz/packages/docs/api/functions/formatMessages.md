[@elizaos/core v1.0.0-beta.32](../index.md) / formatMessages

# Function: formatMessages()

> **formatMessages**(`params`): `string`

Format messages into a string

## Parameters

• **params**

The formatting parameters

• **params.messages**: [`Memory`](../interfaces/Memory.md)[]

List of messages to format

• **params.entities**: [`Entity`](../interfaces/Entity.md)[]

List of entities for name resolution

## Returns

`string`

Formatted message string with timestamps and user information

## Defined in

[packages/core/src/prompts.ts:204](https://github.com/elizaOS/eliza/blob/main/packages/core/src/prompts.ts#L204)
