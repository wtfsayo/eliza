[@elizaos/core v1.0.0-beta.32](../index.md) / validateUuid

# Function: validateUuid()

> **validateUuid**(`value`): \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Validate if the given value is a valid UUID.

## Parameters

• **value**: `unknown`

The value to be validated.

## Returns

\`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

The validated UUID value or null if validation fails.

## Defined in

[packages/core/src/uuid.ts:19](https://github.com/elizaOS/eliza/blob/main/packages/core/src/uuid.ts#L19)
