[@elizaos/core v1.0.0-beta.32](../index.md) / composePrompt

# Function: composePrompt()

> **composePrompt**(`options`): `string`

Function to compose a prompt using a provided template and state.

## Parameters

• **options**

Object containing state and template information.

• **options.state**

The state object containing values to fill the template.

• **options.template**: `TemplateType`

The template to be used for composing the prompt.

## Returns

`string`

The composed prompt output.

## Defined in

[packages/core/src/prompts.ts:45](https://github.com/elizaOS/eliza/blob/main/packages/core/src/prompts.ts#L45)
