[@elizaos/core v1.0.0-beta.32](../index.md) / PlatformPrefix

# Enumeration: PlatformPrefix

Platform-specific event type prefix

## Enumeration Members

### DISCORD

> **DISCORD**: `"DISCORD"`

#### Defined in

[packages/core/src/types.ts:1547](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1547)

***

### TELEGRAM

> **TELEGRAM**: `"TELEGRAM"`

#### Defined in

[packages/core/src/types.ts:1548](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1548)

***

### TWITTER

> **TWITTER**: `"TWITTER"`

#### Defined in

[packages/core/src/types.ts:1549](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1549)
