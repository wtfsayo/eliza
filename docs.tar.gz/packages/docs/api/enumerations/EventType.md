[@elizaos/core v1.0.0-beta.32](../index.md) / EventType

# Enumeration: EventType

Standard event types across all platforms

## Enumeration Members

### WORLD\_JOINED

> **WORLD\_JOINED**: `"WORLD_JOINED"`

#### Defined in

[packages/core/src/types.ts:1503](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1503)

***

### WORLD\_CONNECTED

> **WORLD\_CONNECTED**: `"WORLD_CONNECTED"`

#### Defined in

[packages/core/src/types.ts:1504](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1504)

***

### WORLD\_LEFT

> **WORLD\_LEFT**: `"WORLD_LEFT"`

#### Defined in

[packages/core/src/types.ts:1505](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1505)

***

### ENTITY\_JOINED

> **ENTITY\_JOINED**: `"ENTITY_JOINED"`

#### Defined in

[packages/core/src/types.ts:1508](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1508)

***

### ENTITY\_LEFT

> **ENTITY\_LEFT**: `"ENTITY_LEFT"`

#### Defined in

[packages/core/src/types.ts:1509](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1509)

***

### ENTITY\_UPDATED

> **ENTITY\_UPDATED**: `"ENTITY_UPDATED"`

#### Defined in

[packages/core/src/types.ts:1510](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1510)

***

### ROOM\_JOINED

> **ROOM\_JOINED**: `"ROOM_JOINED"`

#### Defined in

[packages/core/src/types.ts:1513](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1513)

***

### ROOM\_LEFT

> **ROOM\_LEFT**: `"ROOM_LEFT"`

#### Defined in

[packages/core/src/types.ts:1514](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1514)

***

### MESSAGE\_RECEIVED

> **MESSAGE\_RECEIVED**: `"MESSAGE_RECEIVED"`

#### Defined in

[packages/core/src/types.ts:1517](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1517)

***

### MESSAGE\_SENT

> **MESSAGE\_SENT**: `"MESSAGE_SENT"`

#### Defined in

[packages/core/src/types.ts:1518](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1518)

***

### VOICE\_MESSAGE\_RECEIVED

> **VOICE\_MESSAGE\_RECEIVED**: `"VOICE_MESSAGE_RECEIVED"`

#### Defined in

[packages/core/src/types.ts:1521](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1521)

***

### VOICE\_MESSAGE\_SENT

> **VOICE\_MESSAGE\_SENT**: `"VOICE_MESSAGE_SENT"`

#### Defined in

[packages/core/src/types.ts:1522](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1522)

***

### REACTION\_RECEIVED

> **REACTION\_RECEIVED**: `"REACTION_RECEIVED"`

#### Defined in

[packages/core/src/types.ts:1525](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1525)

***

### POST\_GENERATED

> **POST\_GENERATED**: `"POST_GENERATED"`

#### Defined in

[packages/core/src/types.ts:1526](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1526)

***

### INTERACTION\_RECEIVED

> **INTERACTION\_RECEIVED**: `"INTERACTION_RECEIVED"`

#### Defined in

[packages/core/src/types.ts:1527](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1527)

***

### RUN\_STARTED

> **RUN\_STARTED**: `"RUN_STARTED"`

#### Defined in

[packages/core/src/types.ts:1530](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1530)

***

### RUN\_ENDED

> **RUN\_ENDED**: `"RUN_ENDED"`

#### Defined in

[packages/core/src/types.ts:1531](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1531)

***

### RUN\_TIMEOUT

> **RUN\_TIMEOUT**: `"RUN_TIMEOUT"`

#### Defined in

[packages/core/src/types.ts:1532](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1532)

***

### ACTION\_STARTED

> **ACTION\_STARTED**: `"ACTION_STARTED"`

#### Defined in

[packages/core/src/types.ts:1535](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1535)

***

### ACTION\_COMPLETED

> **ACTION\_COMPLETED**: `"ACTION_COMPLETED"`

#### Defined in

[packages/core/src/types.ts:1536](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1536)

***

### EVALUATOR\_STARTED

> **EVALUATOR\_STARTED**: `"EVALUATOR_STARTED"`

#### Defined in

[packages/core/src/types.ts:1539](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1539)

***

### EVALUATOR\_COMPLETED

> **EVALUATOR\_COMPLETED**: `"EVALUATOR_COMPLETED"`

#### Defined in

[packages/core/src/types.ts:1540](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1540)
