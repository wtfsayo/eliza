[@elizaos/core v1.0.0-beta.32](../index.md) / SOCKET\_MESSAGE\_TYPE

# Enumeration: SOCKET\_MESSAGE\_TYPE

Update the Plugin interface with typed events

## Enumeration Members

### ROOM\_JOINING

> **ROOM\_JOINING**: `1`

#### Defined in

[packages/core/src/types.ts:1692](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1692)

***

### SEND\_MESSAGE

> **SEND\_MESSAGE**: `2`

#### Defined in

[packages/core/src/types.ts:1693](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1693)

***

### MESSAGE

> **MESSAGE**: `3`

#### Defined in

[packages/core/src/types.ts:1694](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1694)

***

### ACK

> **ACK**: `4`

#### Defined in

[packages/core/src/types.ts:1695](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1695)

***

### THINKING

> **THINKING**: `5`

#### Defined in

[packages/core/src/types.ts:1696](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1696)
