[@elizaos/core v1.0.0-beta.32](../index.md) / EnhancedState

# Interface: EnhancedState

Enhanced State interface with more specific types
