[@elizaos/core v1.0.0-beta.32](../index.md) / EmbeddingSearchResult

# Interface: EmbeddingSearchResult

Result interface for embedding similarity searches
