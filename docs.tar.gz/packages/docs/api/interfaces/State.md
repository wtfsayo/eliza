[@elizaos/core v1.0.0-beta.32](../index.md) / State

# Interface: State

Represents the current state/context of a conversation

## Indexable

 \[`key`: `string`\]: `any`
