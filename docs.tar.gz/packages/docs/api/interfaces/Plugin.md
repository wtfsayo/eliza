[@elizaos/core v1.0.0-beta.32](../index.md) / Plugin

# Interface: Plugin

Plugin for extending agent functionality
