[@elizaos/core v1.0.0-beta.32](../index.md) / MessagePayload

# Interface: MessagePayload

Payload for reaction-related events

## Extends

- [`EventPayload`](EventPayload.md)
