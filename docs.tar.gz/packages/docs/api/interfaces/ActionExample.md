[@elizaos/core v1.0.0-beta.32](../index.md) / ActionExample

# Interface: ActionExample

Example content with associated user for demonstration purposes

## Properties

### name

> **name**: `string`

User associated with the example

#### Defined in

[packages/core/src/types.ts:62](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L62)

***

### content

> **content**: [`Content`](Content.md)

Content of the example

#### Defined in

[packages/core/src/types.ts:65](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L65)
