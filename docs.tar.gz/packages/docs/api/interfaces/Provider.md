[@elizaos/core v1.0.0-beta.32](../index.md) / Provider

# Interface: Provider

Provider for external data/services

## Properties

### name

> **name**: `string`

Provider name

#### Defined in

[packages/core/src/types.ts:352](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L352)

***

### description?

> `optional` **description**: `string`

Description of the provider

#### Defined in

[packages/core/src/types.ts:355](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L355)

***

### dynamic?

> `optional` **dynamic**: `boolean`

Whether the provider is dynamic

#### Defined in

[packages/core/src/types.ts:358](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L358)

***

### position?

> `optional` **position**: `number`

Position of the provider in the provider list, positive or negative

#### Defined in

[packages/core/src/types.ts:361](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L361)

***

### private?

> `optional` **private**: `boolean`

Whether the provider is private

Private providers are not displayed in the regular provider list, they have to be called explicitly

#### Defined in

[packages/core/src/types.ts:368](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L368)

***

### get()

> **get**: (`runtime`, `message`, `state`) => `Promise`\<`ProviderResult`\>

Data retrieval function

#### Parameters

• **runtime**: `IAgentRuntime`

• **message**: [`Memory`](Memory.md)

• **state**: [`State`](State.md)

#### Returns

`Promise`\<`ProviderResult`\>

#### Defined in

[packages/core/src/types.ts:371](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L371)
