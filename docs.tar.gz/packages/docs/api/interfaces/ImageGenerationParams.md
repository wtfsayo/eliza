[@elizaos/core v1.0.0-beta.32](../index.md) / ImageGenerationParams

# Interface: ImageGenerationParams

Parameters for image generation models

## Extends

- [`BaseModelParams`](BaseModelParams.md)

## Properties

### runtime

> **runtime**: `IAgentRuntime`

The agent runtime for accessing services and utilities

#### Inherited from

[`BaseModelParams`](BaseModelParams.md).[`runtime`](BaseModelParams.md#runtime)

#### Defined in

[packages/core/src/types.ts:1307](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1307)

***

### prompt

> **prompt**: `string`

The prompt describing the image to generate

#### Defined in

[packages/core/src/types.ts:1361](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1361)

***

### size?

> `optional` **size**: `string`

The dimensions of the image to generate

#### Defined in

[packages/core/src/types.ts:1363](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1363)

***

### count?

> `optional` **count**: `number`

Number of images to generate

#### Defined in

[packages/core/src/types.ts:1365](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1365)
