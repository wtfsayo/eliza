[@elizaos/core v1.0.0-beta.32](../index.md) / ServiceError

# Interface: ServiceError

Standardized service error type for consistent error handling
