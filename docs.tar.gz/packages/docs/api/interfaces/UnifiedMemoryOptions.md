[@elizaos/core v1.0.0-beta.32](../index.md) / UnifiedMemoryOptions

# Interface: UnifiedMemoryOptions

Unified options pattern for memory operations
Provides a simpler, more consistent interface

## Extended by

- [`UnifiedSearchOptions`](UnifiedSearchOptions.md)
