[@elizaos/core v1.0.0-beta.32](../index.md) / EvaluatorEventPayload

# Interface: EvaluatorEventPayload

Evaluator event payload type

## Extends

- [`EventPayload`](EventPayload.md)
