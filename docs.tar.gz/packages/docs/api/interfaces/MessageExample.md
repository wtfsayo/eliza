[@elizaos/core v1.0.0-beta.32](../index.md) / MessageExample

# Interface: MessageExample

Example message for demonstration

## Properties

### name

> **name**: `string`

Associated user

#### Defined in

[packages/core/src/types.ts:242](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L242)

***

### content

> **content**: [`Content`](Content.md)

Message content

#### Defined in

[packages/core/src/types.ts:245](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L245)
