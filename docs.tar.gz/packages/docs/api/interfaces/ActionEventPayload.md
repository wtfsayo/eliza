[@elizaos/core v1.0.0-beta.32](../index.md) / ActionEventPayload

# Interface: ActionEventPayload

Action event payload type

## Extends

- [`EventPayload`](EventPayload.md)
