[@elizaos/core v1.0.0-beta.32](../index.md) / MessageMemory

# Interface: MessageMemory

Specialized memory type for messages with enhanced type checking

## Extends

- [`Memory`](Memory.md)

## Properties

### id?

> `optional` **id**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Optional unique identifier

#### Inherited from

[`Memory`](Memory.md).[`id`](Memory.md#id)

#### Defined in

[packages/core/src/types.ts:184](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L184)

***

### entityId

> **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Associated user ID

#### Inherited from

[`Memory`](Memory.md).[`entityId`](Memory.md#entityId)

#### Defined in

[packages/core/src/types.ts:187](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L187)

***

### agentId?

> `optional` **agentId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Associated agent ID

#### Inherited from

[`Memory`](Memory.md).[`agentId`](Memory.md#agentId)

#### Defined in

[packages/core/src/types.ts:190](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L190)

***

### createdAt?

> `optional` **createdAt**: `number`

Optional creation timestamp in milliseconds since epoch

#### Inherited from

[`Memory`](Memory.md).[`createdAt`](Memory.md#createdAt)

#### Defined in

[packages/core/src/types.ts:193](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L193)

***

### embedding?

> `optional` **embedding**: `number`[]

Optional embedding vector for semantic search

#### Inherited from

[`Memory`](Memory.md).[`embedding`](Memory.md#embedding)

#### Defined in

[packages/core/src/types.ts:199](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L199)

***

### roomId

> **roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Associated room ID

#### Inherited from

[`Memory`](Memory.md).[`roomId`](Memory.md#roomId)

#### Defined in

[packages/core/src/types.ts:202](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L202)

***

### unique?

> `optional` **unique**: `boolean`

Whether memory is unique (used to prevent duplicates)

#### Inherited from

[`Memory`](Memory.md).[`unique`](Memory.md#unique)

#### Defined in

[packages/core/src/types.ts:205](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L205)

***

### similarity?

> `optional` **similarity**: `number`

Embedding similarity score (set when retrieved via search)

#### Inherited from

[`Memory`](Memory.md).[`similarity`](Memory.md#similarity)

#### Defined in

[packages/core/src/types.ts:208](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L208)

***

### metadata

> **metadata**: `MessageMetadata`

Metadata for the memory

#### Overrides

[`Memory`](Memory.md).[`metadata`](Memory.md#metadata)

#### Defined in

[packages/core/src/types.ts:1703](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1703)

***

### content

> **content**: [`Content`](Content.md) & `object`

Memory content

#### Type declaration

##### text

> **text**: `string`

#### Overrides

[`Memory`](Memory.md).[`content`](Memory.md#content)

#### Defined in

[packages/core/src/types.ts:1704](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1704)
