[@elizaos/core v1.0.0-beta.32](../index.md) / TokenizeTextParams

# Interface: TokenizeTextParams

Parameters for text tokenization models

## Extends

- [`BaseModelParams`](BaseModelParams.md)

## Properties

### prompt

> **prompt**: `string`

The text to tokenize

#### Defined in

[packages/core/src/types.ts:1138](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1138)

***

### modelType

> **modelType**: `string`

The model type to use for tokenization

#### Defined in

[packages/core/src/types.ts:1139](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1139)

***

### runtime

> **runtime**: `IAgentRuntime`

The agent runtime for accessing services and utilities

#### Inherited from

[`BaseModelParams`](BaseModelParams.md).[`runtime`](BaseModelParams.md#runtime)

#### Defined in

[packages/core/src/types.ts:1307](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1307)
