[@elizaos/core v1.0.0-beta.32](../index.md) / TextToSpeechParams

# Interface: TextToSpeechParams

Parameters for text-to-speech models

## Extends

- [`BaseModelParams`](BaseModelParams.md)

## Properties

### runtime

> **runtime**: `IAgentRuntime`

The agent runtime for accessing services and utilities

#### Inherited from

[`BaseModelParams`](BaseModelParams.md).[`runtime`](BaseModelParams.md#runtime)

#### Defined in

[packages/core/src/types.ts:1307](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1307)

***

### text

> **text**: `string`

The text to convert to speech

#### Defined in

[packages/core/src/types.ts:1393](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1393)

***

### voice?

> `optional` **voice**: `string`

The voice to use

#### Defined in

[packages/core/src/types.ts:1395](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1395)

***

### speed?

> `optional` **speed**: `number`

The speaking speed

#### Defined in

[packages/core/src/types.ts:1397](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1397)
