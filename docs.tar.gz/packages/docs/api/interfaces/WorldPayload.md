[@elizaos/core v1.0.0-beta.32](../index.md) / WorldPayload

# Interface: WorldPayload

Payload for world-related events

## Extends

- [`EventPayload`](EventPayload.md)
