[@elizaos/core v1.0.0-beta.32](../index.md) / EvaluationExample

# Interface: EvaluationExample

Example for evaluating agent behavior

## Properties

### prompt

> **prompt**: `string`

Evaluation context

#### Defined in

[packages/core/src/types.ts:302](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L302)

***

### messages

> **messages**: [`ActionExample`](ActionExample.md)[]

Example messages

#### Defined in

[packages/core/src/types.ts:305](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L305)

***

### outcome

> **outcome**: `string`

Expected outcome

#### Defined in

[packages/core/src/types.ts:308](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L308)
