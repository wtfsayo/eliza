[@elizaos/core v1.0.0-beta.32](../index.md) / IDatabaseAdapter

# Interface: IDatabaseAdapter

Interface for database operations

## Properties

### db

> **db**: `any`

Database instance

#### Defined in

[packages/core/src/types.ts:687](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L687)

## Methods

### init()

> **init**(): `Promise`\<`void`\>

Initialize database connection

#### Returns

`Promise`\<`void`\>

#### Defined in

[packages/core/src/types.ts:690](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L690)

***

### close()

> **close**(): `Promise`\<`void`\>

Close database connection

#### Returns

`Promise`\<`void`\>

#### Defined in

[packages/core/src/types.ts:693](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L693)

***

### getAgents()

> **getAgents**(): `Promise`\<`Agent`[]\>

Get all agents

#### Returns

`Promise`\<`Agent`[]\>

#### Defined in

[packages/core/src/types.ts:698](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L698)

***

### getEntityById()

> **getEntityById**(`entityId`): `Promise`\<[`Entity`](Entity.md)\>

Get entity by ID

#### Parameters

• **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

#### Returns

`Promise`\<[`Entity`](Entity.md)\>

#### Defined in

[packages/core/src/types.ts:711](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L711)

***

### getEntitiesForRoom()

> **getEntitiesForRoom**(`roomId`, `includeComponents`?): `Promise`\<[`Entity`](Entity.md)[]\>

Get entities for room

#### Parameters

• **roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **includeComponents?**: `boolean`

#### Returns

`Promise`\<[`Entity`](Entity.md)[]\>

#### Defined in

[packages/core/src/types.ts:714](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L714)

***

### createEntity()

> **createEntity**(`entity`): `Promise`\<`boolean`\>

Create new entity

#### Parameters

• **entity**: [`Entity`](Entity.md)

#### Returns

`Promise`\<`boolean`\>

#### Defined in

[packages/core/src/types.ts:717](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L717)

***

### updateEntity()

> **updateEntity**(`entity`): `Promise`\<`void`\>

Update entity

#### Parameters

• **entity**: [`Entity`](Entity.md)

#### Returns

`Promise`\<`void`\>

#### Defined in

[packages/core/src/types.ts:720](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L720)

***

### getComponent()

> **getComponent**(`entityId`, `type`, `worldId`?, `sourceEntityId`?): `Promise`\<`Component`\>

Get component by ID

#### Parameters

• **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **type**: `string`

• **worldId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **sourceEntityId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

#### Returns

`Promise`\<`Component`\>

#### Defined in

[packages/core/src/types.ts:723](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L723)

***

### getComponents()

> **getComponents**(`entityId`, `worldId`?, `sourceEntityId`?): `Promise`\<`Component`[]\>

Get all components for an entity

#### Parameters

• **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **worldId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **sourceEntityId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

#### Returns

`Promise`\<`Component`[]\>

#### Defined in

[packages/core/src/types.ts:731](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L731)

***

### createComponent()

> **createComponent**(`component`): `Promise`\<`boolean`\>

Create component

#### Parameters

• **component**: `Component`

#### Returns

`Promise`\<`boolean`\>

#### Defined in

[packages/core/src/types.ts:734](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L734)

***

### updateComponent()

> **updateComponent**(`component`): `Promise`\<`void`\>

Update component

#### Parameters

• **component**: `Component`

#### Returns

`Promise`\<`void`\>

#### Defined in

[packages/core/src/types.ts:737](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L737)

***

### deleteComponent()

> **deleteComponent**(`componentId`): `Promise`\<`void`\>

Delete component

#### Parameters

• **componentId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

#### Returns

`Promise`\<`void`\>

#### Defined in

[packages/core/src/types.ts:740](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L740)

***

### getMemories()

> **getMemories**(`params`): `Promise`\<[`Memory`](Memory.md)[]\>

Get memories matching criteria

#### Parameters

• **params**

• **params.entityId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.agentId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.roomId?**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.count?**: `number`

• **params.unique?**: `boolean`

• **params.tableName**: `string`

• **params.start?**: `number`

• **params.end?**: `number`

#### Returns

`Promise`\<[`Memory`](Memory.md)[]\>

#### Defined in

[packages/core/src/types.ts:743](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L743)

***

### createRelationship()

> **createRelationship**(`params`): `Promise`\<`boolean`\>

Creates a new relationship between two entities.

#### Parameters

• **params**

Object containing the relationship details

• **params.sourceEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.targetEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.tags?**: `string`[]

• **params.metadata?**

#### Returns

`Promise`\<`boolean`\>

Promise resolving to boolean indicating success

#### Defined in

[packages/core/src/types.ts:852](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L852)

***

### updateRelationship()

> **updateRelationship**(`relationship`): `Promise`\<`void`\>

Updates an existing relationship between two entities.

#### Parameters

• **relationship**: [`Relationship`](Relationship.md)

The relationship object with updated data

#### Returns

`Promise`\<`void`\>

Promise resolving to void

#### Defined in

[packages/core/src/types.ts:864](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L864)

***

### getRelationship()

> **getRelationship**(`params`): `Promise`\<[`Relationship`](Relationship.md)\>

Retrieves a relationship between two entities if it exists.

#### Parameters

• **params**

Object containing the entity IDs and agent ID

• **params.sourceEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.targetEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

#### Returns

`Promise`\<[`Relationship`](Relationship.md)\>

Promise resolving to the Relationship object or null if not found

#### Defined in

[packages/core/src/types.ts:871](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L871)

***

### getRelationships()

> **getRelationships**(`params`): `Promise`\<[`Relationship`](Relationship.md)[]\>

Retrieves all relationships for a specific entity.

#### Parameters

• **params**

Object containing the user ID, agent ID and optional tags to filter by

• **params.entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

• **params.tags?**: `string`[]

#### Returns

`Promise`\<[`Relationship`](Relationship.md)[]\>

Promise resolving to an array of Relationship objects

#### Defined in

[packages/core/src/types.ts:881](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L881)
