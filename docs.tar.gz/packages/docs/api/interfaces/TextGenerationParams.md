[@elizaos/core v1.0.0-beta.32](../index.md) / TextGenerationParams

# Interface: TextGenerationParams

Parameters for text generation models

## Extends

- [`BaseModelParams`](BaseModelParams.md)

## Properties

### runtime

> **runtime**: `IAgentRuntime`

The agent runtime for accessing services and utilities

#### Inherited from

[`BaseModelParams`](BaseModelParams.md).[`runtime`](BaseModelParams.md#runtime)

#### Defined in

[packages/core/src/types.ts:1307](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1307)

***

### prompt

> **prompt**: `string`

The prompt to generate text from

#### Defined in

[packages/core/src/types.ts:1315](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1315)

***

### temperature?

> `optional` **temperature**: `number`

Model temperature (0.0 to 1.0, lower is more deterministic)

#### Defined in

[packages/core/src/types.ts:1317](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1317)

***

### maxTokens?

> `optional` **maxTokens**: `number`

Maximum number of tokens to generate

#### Defined in

[packages/core/src/types.ts:1319](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1319)

***

### stopSequences?

> `optional` **stopSequences**: `string`[]

Sequences that should stop generation when encountered

#### Defined in

[packages/core/src/types.ts:1321](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1321)

***

### frequencyPenalty?

> `optional` **frequencyPenalty**: `number`

Frequency penalty to apply

#### Defined in

[packages/core/src/types.ts:1323](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1323)

***

### presencePenalty?

> `optional` **presencePenalty**: `number`

Presence penalty to apply

#### Defined in

[packages/core/src/types.ts:1325](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1325)
