[@elizaos/core v1.0.0-beta.32](../index.md) / BaseModelParams

# Interface: BaseModelParams

Base parameters common to all model types

## Extended by

- [`TokenizeTextParams`](TokenizeTextParams.md)
- [`DetokenizeTextParams`](DetokenizeTextParams.md)
- [`TextGenerationParams`](TextGenerationParams.md)
- [`TextEmbeddingParams`](TextEmbeddingParams.md)
- [`ImageGenerationParams`](ImageGenerationParams.md)
- [`ImageDescriptionParams`](ImageDescriptionParams.md)
- [`TranscriptionParams`](TranscriptionParams.md)
- [`TextToSpeechParams`](TextToSpeechParams.md)
- [`AudioProcessingParams`](AudioProcessingParams.md)
- [`VideoProcessingParams`](VideoProcessingParams.md)
- [`ObjectGenerationParams`](ObjectGenerationParams.md)

## Properties

### runtime

> **runtime**: `IAgentRuntime`

The agent runtime for accessing services and utilities

#### Defined in

[packages/core/src/types.ts:1307](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1307)
