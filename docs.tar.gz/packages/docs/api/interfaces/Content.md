[@elizaos/core v1.0.0-beta.32](../index.md) / Content

# Interface: Content

Represents the content of a memory, message, or other information

## Indexable

 \[`key`: `string`\]: `unknown`

## Properties

### thought?

> `optional` **thought**: `string`

The agent's internal thought process

#### Defined in

[packages/core/src/types.ts:27](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L27)

***

### text?

> `optional` **text**: `string`

The main text content visible to users

#### Defined in

[packages/core/src/types.ts:30](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L30)

***

### actions?

> `optional` **actions**: `string`[]

Optional actions to be performed

#### Defined in

[packages/core/src/types.ts:33](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L33)

***

### providers?

> `optional` **providers**: `string`[]

Optional providers to use for context generation

#### Defined in

[packages/core/src/types.ts:36](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L36)

***

### source?

> `optional` **source**: `string`

Optional source/origin of the content

#### Defined in

[packages/core/src/types.ts:39](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L39)

***

### url?

> `optional` **url**: `string`

URL of the original message/post (e.g. tweet URL, Discord message link)

#### Defined in

[packages/core/src/types.ts:42](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L42)

***

### inReplyTo?

> `optional` **inReplyTo**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

UUID of parent message if this is a reply/thread

#### Defined in

[packages/core/src/types.ts:45](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L45)

***

### attachments?

> `optional` **attachments**: [`Media`](../type-aliases/Media.md)[]

Array of media attachments

#### Defined in

[packages/core/src/types.ts:48](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L48)
