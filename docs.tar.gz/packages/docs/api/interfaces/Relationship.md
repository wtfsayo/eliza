[@elizaos/core v1.0.0-beta.32](../index.md) / Relationship

# Interface: Relationship

Represents a relationship between users

## Properties

### id

> **id**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Unique identifier

#### Defined in

[packages/core/src/types.ts:379](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L379)

***

### sourceEntityId

> **sourceEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

First user ID

#### Defined in

[packages/core/src/types.ts:382](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L382)

***

### targetEntityId

> **targetEntityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Second user ID

#### Defined in

[packages/core/src/types.ts:385](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L385)

***

### agentId

> **agentId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Agent ID

#### Defined in

[packages/core/src/types.ts:388](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L388)

***

### tags

> **tags**: `string`[]

Tags for filtering/categorizing relationships

#### Defined in

[packages/core/src/types.ts:391](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L391)

***

### metadata

> **metadata**: `object`

Additional metadata about the relationship

#### Index Signature

 \[`key`: `string`\]: `any`

#### Defined in

[packages/core/src/types.ts:394](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L394)

***

### createdAt?

> `optional` **createdAt**: `string`

Optional creation timestamp

#### Defined in

[packages/core/src/types.ts:399](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L399)
