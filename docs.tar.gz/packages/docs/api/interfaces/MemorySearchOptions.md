[@elizaos/core v1.0.0-beta.32](../index.md) / MemorySearchOptions

# Interface: MemorySearchOptions

Options for memory search operations
