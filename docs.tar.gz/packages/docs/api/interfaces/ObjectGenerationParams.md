[@elizaos/core v1.0.0-beta.32](../index.md) / ObjectGenerationParams

# Interface: ObjectGenerationParams\<T\>

Parameters for object generation models

## Extends

- [`BaseModelParams`](BaseModelParams.md)

## Type Parameters

• **T** = `any`

The expected return type, inferred from schema if provided

## Properties

### runtime

> **runtime**: `IAgentRuntime`

The agent runtime for accessing services and utilities

#### Inherited from

[`BaseModelParams`](BaseModelParams.md).[`runtime`](BaseModelParams.md#runtime)

#### Defined in

[packages/core/src/types.ts:1307](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1307)

***

### prompt

> **prompt**: `string`

The prompt describing the object to generate

#### Defined in

[packages/core/src/types.ts:1437](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1437)

***

### schema?

> `optional` **schema**: [`JSONSchema`](../type-aliases/JSONSchema.md)

Optional JSON schema for validation

#### Defined in

[packages/core/src/types.ts:1439](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1439)

***

### output?

> `optional` **output**: `"object"` \| `"array"` \| `"enum"`

Type of object to generate

#### Defined in

[packages/core/src/types.ts:1441](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1441)

***

### enumValues?

> `optional` **enumValues**: `string`[]

For enum type, the allowed values

#### Defined in

[packages/core/src/types.ts:1443](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1443)

***

### modelType?

> `optional` **modelType**: `string`

Model type to use

#### Defined in

[packages/core/src/types.ts:1445](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1445)

***

### temperature?

> `optional` **temperature**: `number`

Model temperature (0.0 to 1.0)

#### Defined in

[packages/core/src/types.ts:1447](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1447)

***

### stopSequences?

> `optional` **stopSequences**: `string`[]

Sequences that should stop generation

#### Defined in

[packages/core/src/types.ts:1449](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1449)
