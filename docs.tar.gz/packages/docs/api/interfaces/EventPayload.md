[@elizaos/core v1.0.0-beta.32](../index.md) / EventPayload

# Interface: EventPayload

Base payload interface for all events

## Extended by

- [`WorldPayload`](WorldPayload.md)
- [`EntityPayload`](EntityPayload.md)
- [`MessagePayload`](MessagePayload.md)
- [`InvokePayload`](InvokePayload.md)
- [`RunEventPayload`](RunEventPayload.md)
- [`ActionEventPayload`](ActionEventPayload.md)
- [`EvaluatorEventPayload`](EvaluatorEventPayload.md)
