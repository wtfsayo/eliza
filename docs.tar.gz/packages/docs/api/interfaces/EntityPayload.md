[@elizaos/core v1.0.0-beta.32](../index.md) / EntityPayload

# Interface: EntityPayload

Payload for entity-related events

## Extends

- [`EventPayload`](EventPayload.md)
