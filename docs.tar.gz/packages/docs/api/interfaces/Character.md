[@elizaos/core v1.0.0-beta.32](../index.md) / Character

# Interface: Character

Configuration for an agent character

## Properties

### id?

> `optional` **id**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Optional unique identifier

#### Defined in

[packages/core/src/types.ts:615](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L615)

***

### name

> **name**: `string`

Character name

#### Defined in

[packages/core/src/types.ts:618](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L618)

***

### username?

> `optional` **username**: `string`

Optional username

#### Defined in

[packages/core/src/types.ts:621](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L621)

***

### system?

> `optional` **system**: `string`

Optional system prompt

#### Defined in

[packages/core/src/types.ts:624](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L624)

***

### templates?

> `optional` **templates**: `object`

Optional prompt templates

#### Index Signature

 \[`key`: `string`\]: `TemplateType`

#### Defined in

[packages/core/src/types.ts:627](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L627)

***

### bio

> **bio**: `string` \| `string`[]

Character biography

#### Defined in

[packages/core/src/types.ts:632](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L632)

***

### messageExamples?

> `optional` **messageExamples**: [`MessageExample`](MessageExample.md)[][]

Example messages

#### Defined in

[packages/core/src/types.ts:635](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L635)

***

### postExamples?

> `optional` **postExamples**: `string`[]

Example posts

#### Defined in

[packages/core/src/types.ts:638](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L638)

***

### topics?

> `optional` **topics**: `string`[]

Known topics

#### Defined in

[packages/core/src/types.ts:641](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L641)

***

### adjectives?

> `optional` **adjectives**: `string`[]

Character traits

#### Defined in

[packages/core/src/types.ts:644](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L644)

***

### knowledge?

> `optional` **knowledge**: (`string` \| `object`)[]

Optional knowledge base

#### Defined in

[packages/core/src/types.ts:647](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L647)

***

### plugins?

> `optional` **plugins**: `string`[]

Available plugins

#### Defined in

[packages/core/src/types.ts:650](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L650)

***

### settings?

> `optional` **settings**: `object`

Optional configuration

#### Index Signature

 \[`key`: `string`\]: `any`

#### Defined in

[packages/core/src/types.ts:653](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L653)

***

### secrets?

> `optional` **secrets**: `object`

Optional secrets

#### Index Signature

 \[`key`: `string`\]: `string` \| `number` \| `boolean`

#### Defined in

[packages/core/src/types.ts:658](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L658)

***

### style?

> `optional` **style**: `object`

Writing style guides

#### all?

> `optional` **all**: `string`[]

#### chat?

> `optional` **chat**: `string`[]

#### post?

> `optional` **post**: `string`[]

#### Defined in

[packages/core/src/types.ts:663](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L663)
