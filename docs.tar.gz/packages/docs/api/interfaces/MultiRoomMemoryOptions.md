[@elizaos/core v1.0.0-beta.32](../index.md) / MultiRoomMemoryOptions

# Interface: MultiRoomMemoryOptions

Options for multi-room memory retrieval
