[@elizaos/core v1.0.0-beta.32](../index.md) / Participant

# Interface: Participant

Room participant with account details

## Properties

### id

> **id**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Unique identifier

#### Defined in

[packages/core/src/types.ts:468](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L468)

***

### entity

> **entity**: [`Entity`](Entity.md)

Associated account

#### Defined in

[packages/core/src/types.ts:471](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L471)
