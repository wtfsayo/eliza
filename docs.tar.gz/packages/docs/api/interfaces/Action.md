[@elizaos/core v1.0.0-beta.32](../index.md) / Action

# Interface: Action

Represents an action the agent can perform

## Properties

### similes?

> `optional` **similes**: `string`[]

Similar action descriptions

#### Defined in

[packages/core/src/types.ts:279](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L279)

***

### description

> **description**: `string`

Detailed description

#### Defined in

[packages/core/src/types.ts:282](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L282)

***

### examples?

> `optional` **examples**: [`ActionExample`](ActionExample.md)[][]

Example usages

#### Defined in

[packages/core/src/types.ts:285](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L285)

***

### handler

> **handler**: [`Handler`](../type-aliases/Handler.md)

Handler function

#### Defined in

[packages/core/src/types.ts:288](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L288)

***

### name

> **name**: `string`

Action name

#### Defined in

[packages/core/src/types.ts:291](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L291)

***

### validate

> **validate**: [`Validator`](../type-aliases/Validator.md)

Validation function

#### Defined in

[packages/core/src/types.ts:294](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L294)
