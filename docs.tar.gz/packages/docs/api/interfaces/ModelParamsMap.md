[@elizaos/core v1.0.0-beta.32](../index.md) / ModelParamsMap

# Interface: ModelParamsMap

Map of model types to their parameter types
