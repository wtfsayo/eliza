[@elizaos/core v1.0.0-beta.32](../index.md) / ModelResultMap

# Interface: ModelResultMap

Map of model types to their return value types
