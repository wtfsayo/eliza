[@elizaos/core v1.0.0-beta.32](../index.md) / MemoryRetrievalOptions

# Interface: MemoryRetrievalOptions

Options for memory retrieval operations
