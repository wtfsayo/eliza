[@elizaos/core v1.0.0-beta.32](../index.md) / AudioProcessingParams

# Interface: AudioProcessingParams

Parameters for audio processing models

## Extends

- [`BaseModelParams`](BaseModelParams.md)

## Properties

### runtime

> **runtime**: `IAgentRuntime`

The agent runtime for accessing services and utilities

#### Inherited from

[`BaseModelParams`](BaseModelParams.md).[`runtime`](BaseModelParams.md#runtime)

#### Defined in

[packages/core/src/types.ts:1307](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1307)

***

### audioUrl

> **audioUrl**: `string`

The URL or path of the audio file to process

#### Defined in

[packages/core/src/types.ts:1405](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1405)

***

### processingType

> **processingType**: `string`

The type of audio processing to perform

#### Defined in

[packages/core/src/types.ts:1407](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1407)
