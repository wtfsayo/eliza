[@elizaos/core v1.0.0-beta.32](../index.md) / ImageDescriptionParams

# Interface: ImageDescriptionParams

Parameters for image description models

## Extends

- [`BaseModelParams`](BaseModelParams.md)

## Properties

### runtime

> **runtime**: `IAgentRuntime`

The agent runtime for accessing services and utilities

#### Inherited from

[`BaseModelParams`](BaseModelParams.md).[`runtime`](BaseModelParams.md#runtime)

#### Defined in

[packages/core/src/types.ts:1307](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1307)

***

### imageUrl

> **imageUrl**: `string`

The URL or path of the image to describe

#### Defined in

[packages/core/src/types.ts:1373](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1373)

***

### prompt?

> `optional` **prompt**: `string`

Optional prompt to guide the description

#### Defined in

[packages/core/src/types.ts:1375](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1375)
