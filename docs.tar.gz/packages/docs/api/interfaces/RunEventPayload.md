[@elizaos/core v1.0.0-beta.32](../index.md) / RunEventPayload

# Interface: RunEventPayload

Run event payload type

## Extends

- [`EventPayload`](EventPayload.md)
