[@elizaos/core v1.0.0-beta.32](../index.md) / VideoProcessingParams

# Interface: VideoProcessingParams

Parameters for video processing models

## Extends

- [`BaseModelParams`](BaseModelParams.md)

## Properties

### runtime

> **runtime**: `IAgentRuntime`

The agent runtime for accessing services and utilities

#### Inherited from

[`BaseModelParams`](BaseModelParams.md).[`runtime`](BaseModelParams.md#runtime)

#### Defined in

[packages/core/src/types.ts:1307](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1307)

***

### videoUrl

> **videoUrl**: `string`

The URL or path of the video file to process

#### Defined in

[packages/core/src/types.ts:1415](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1415)

***

### processingType

> **processingType**: `string`

The type of video processing to perform

#### Defined in

[packages/core/src/types.ts:1417](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1417)
