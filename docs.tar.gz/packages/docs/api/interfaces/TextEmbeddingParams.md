[@elizaos/core v1.0.0-beta.32](../index.md) / TextEmbeddingParams

# Interface: TextEmbeddingParams

Parameters for text embedding models

## Extends

- [`BaseModelParams`](BaseModelParams.md)

## Properties

### runtime

> **runtime**: `IAgentRuntime`

The agent runtime for accessing services and utilities

#### Inherited from

[`BaseModelParams`](BaseModelParams.md).[`runtime`](BaseModelParams.md#runtime)

#### Defined in

[packages/core/src/types.ts:1307](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1307)

***

### text

> **text**: `string`

The text to create embeddings for

#### Defined in

[packages/core/src/types.ts:1333](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1333)
