[@elizaos/core v1.0.0-beta.32](../index.md) / TypedService

# Interface: TypedService\<ConfigType, ResultType\>

Generic service interface that provides better type checking for services

## Extends

- [`Service`](../classes/Service.md)

## Type Parameters

• **ConfigType** = `unknown`

The configuration type for this service

• **ResultType** = `unknown`

The result type returned by the service operations

## Properties

### runtime

> `protected` **runtime**: `IAgentRuntime`

Runtime instance

#### Inherited from

[`Service`](../classes/Service.md).[`runtime`](../classes/Service.md#runtime)

#### Defined in

[packages/core/src/types.ts:519](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L519)

***

### capabilityDescription

> `abstract` **capabilityDescription**: `string`

Service name

#### Inherited from

[`Service`](../classes/Service.md).[`capabilityDescription`](../classes/Service.md#capabilityDescription)

#### Defined in

[packages/core/src/types.ts:533](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L533)

***

### config

> **config**: `ConfigType`

The configuration for this service instance

#### Overrides

[`Service`](../classes/Service.md).[`config`](../classes/Service.md#config)

#### Defined in

[packages/core/src/types.ts:1740](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1740)

## Methods

### process()

> **process**(`input`): `Promise`\<`ResultType`\>

Process an input with this service

#### Parameters

• **input**: `unknown`

The input to process

#### Returns

`Promise`\<`ResultType`\>

A promise resolving to the result

#### Defined in

[packages/core/src/types.ts:1747](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1747)
