[@elizaos/core v1.0.0-beta.32](../index.md) / Log

# Interface: Log

Represents a log entry

## Properties

### id?

> `optional` **id**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Optional unique identifier

#### Defined in

[packages/core/src/types.ts:219](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L219)

***

### entityId

> **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Associated entity ID

#### Defined in

[packages/core/src/types.ts:222](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L222)

***

### roomId?

> `optional` **roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Associated room ID

#### Defined in

[packages/core/src/types.ts:225](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L225)

***

### body

> **body**: `object`

Log body

#### Index Signature

 \[`key`: `string`\]: `unknown`

#### Defined in

[packages/core/src/types.ts:228](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L228)

***

### type

> **type**: `string`

Log type

#### Defined in

[packages/core/src/types.ts:231](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L231)

***

### createdAt

> **createdAt**: `Date`

Log creation timestamp

#### Defined in

[packages/core/src/types.ts:234](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L234)
