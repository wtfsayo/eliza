[@elizaos/core v1.0.0-beta.32](../index.md) / ServerOwnershipState

# Interface: ServerOwnershipState

Interface representing the ownership state of servers.
