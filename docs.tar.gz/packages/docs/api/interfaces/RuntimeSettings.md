[@elizaos/core v1.0.0-beta.32](../index.md) / RuntimeSettings

# Interface: RuntimeSettings

Interface representing settings with string key-value pairs.
