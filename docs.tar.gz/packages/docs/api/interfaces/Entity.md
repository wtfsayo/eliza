[@elizaos/core v1.0.0-beta.32](../index.md) / Entity

# Interface: Entity

Represents a user account

## Properties

### id?

> `optional` **id**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Unique identifier, optional on creation

#### Defined in

[packages/core/src/types.ts:420](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L420)

***

### names

> **names**: `string`[]

Names of the entity

#### Defined in

[packages/core/src/types.ts:423](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L423)

***

### metadata?

> `optional` **metadata**: `object`

Optional additional metadata

#### Index Signature

 \[`key`: `string`\]: `any`

#### Defined in

[packages/core/src/types.ts:426](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L426)

***

### agentId

> **agentId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Agent ID this account is related to, for agents should be themselves

#### Defined in

[packages/core/src/types.ts:429](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L429)

***

### components?

> `optional` **components**: `Component`[]

Optional array of components

#### Defined in

[packages/core/src/types.ts:432](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L432)
