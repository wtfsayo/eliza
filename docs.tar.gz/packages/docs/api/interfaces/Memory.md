[@elizaos/core v1.0.0-beta.32](../index.md) / Memory

# Interface: Memory

Represents a stored memory/message

## Extended by

- [`MessageMemory`](MessageMemory.md)

## Properties

### id?

> `optional` **id**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Optional unique identifier

#### Defined in

[packages/core/src/types.ts:184](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L184)

***

### entityId

> **entityId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Associated user ID

#### Defined in

[packages/core/src/types.ts:187](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L187)

***

### agentId?

> `optional` **agentId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Associated agent ID

#### Defined in

[packages/core/src/types.ts:190](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L190)

***

### createdAt?

> `optional` **createdAt**: `number`

Optional creation timestamp in milliseconds since epoch

#### Defined in

[packages/core/src/types.ts:193](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L193)

***

### content

> **content**: [`Content`](Content.md)

Memory content

#### Defined in

[packages/core/src/types.ts:196](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L196)

***

### embedding?

> `optional` **embedding**: `number`[]

Optional embedding vector for semantic search

#### Defined in

[packages/core/src/types.ts:199](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L199)

***

### roomId

> **roomId**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Associated room ID

#### Defined in

[packages/core/src/types.ts:202](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L202)

***

### unique?

> `optional` **unique**: `boolean`

Whether memory is unique (used to prevent duplicates)

#### Defined in

[packages/core/src/types.ts:205](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L205)

***

### similarity?

> `optional` **similarity**: `number`

Embedding similarity score (set when retrieved via search)

#### Defined in

[packages/core/src/types.ts:208](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L208)

***

### metadata?

> `optional` **metadata**: `MemoryMetadata`

Metadata for the memory

#### Defined in

[packages/core/src/types.ts:211](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L211)
