[@elizaos/core v1.0.0-beta.32](../index.md) / InvokePayload

# Interface: InvokePayload

Payload for events that are invoked without a message

## Extends

- [`EventPayload`](EventPayload.md)
