[@elizaos/core v1.0.0-beta.32](../index.md) / BaseMetadata

# Interface: BaseMetadata

Base interface for all memory metadata types
