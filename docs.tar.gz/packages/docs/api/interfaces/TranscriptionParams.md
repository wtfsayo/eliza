[@elizaos/core v1.0.0-beta.32](../index.md) / TranscriptionParams

# Interface: TranscriptionParams

Parameters for transcription models

## Extends

- [`BaseModelParams`](BaseModelParams.md)

## Properties

### runtime

> **runtime**: `IAgentRuntime`

The agent runtime for accessing services and utilities

#### Inherited from

[`BaseModelParams`](BaseModelParams.md).[`runtime`](BaseModelParams.md#runtime)

#### Defined in

[packages/core/src/types.ts:1307](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1307)

***

### audioUrl

> **audioUrl**: `string`

The URL or path of the audio file to transcribe

#### Defined in

[packages/core/src/types.ts:1383](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1383)

***

### prompt?

> `optional` **prompt**: `string`

Optional prompt to guide transcription

#### Defined in

[packages/core/src/types.ts:1385](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1385)
