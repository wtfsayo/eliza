[@elizaos/core v1.0.0-beta.32](../index.md) / EventPayloadMap

# Interface: EventPayloadMap

Maps event types to their corresponding payload types
