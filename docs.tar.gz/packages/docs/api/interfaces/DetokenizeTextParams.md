[@elizaos/core v1.0.0-beta.32](../index.md) / DetokenizeTextParams

# Interface: DetokenizeTextParams

Parameters for text detokenization models

## Extends

- [`BaseModelParams`](BaseModelParams.md)

## Properties

### tokens

> **tokens**: `number`[]

The tokens to convert back to text

#### Defined in

[packages/core/src/types.ts:1143](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1143)

***

### modelType

> **modelType**: `string`

The model type to use for detokenization

#### Defined in

[packages/core/src/types.ts:1144](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1144)

***

### runtime

> **runtime**: `IAgentRuntime`

The agent runtime for accessing services and utilities

#### Inherited from

[`BaseModelParams`](BaseModelParams.md).[`runtime`](BaseModelParams.md#runtime)

#### Defined in

[packages/core/src/types.ts:1307](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1307)
