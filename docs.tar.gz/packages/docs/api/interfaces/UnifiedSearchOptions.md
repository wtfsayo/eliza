[@elizaos/core v1.0.0-beta.32](../index.md) / UnifiedSearchOptions

# Interface: UnifiedSearchOptions

Specialized memory search options

## Extends

- [`UnifiedMemoryOptions`](UnifiedMemoryOptions.md)
