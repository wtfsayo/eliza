[@elizaos/core v1.0.0-beta.32](../index.md) / UUID

# Type Alias: UUID

> **UUID**: \`$\{string\}-$\{string\}-$\{string\}-$\{string\}-$\{string\}\`

Defines a custom type UUID representing a universally unique identifier

## Defined in

[packages/core/src/types.ts:8](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L8)
