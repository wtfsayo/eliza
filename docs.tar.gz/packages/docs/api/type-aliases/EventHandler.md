[@elizaos/core v1.0.0-beta.32](../index.md) / EventHandler

# Type Alias: EventHandler()\<T\>

> **EventHandler**\<`T`\>: (`payload`) => `Promise`\<`void`\>

Event handler function type

## Type Parameters

• **T** *extends* keyof [`EventPayloadMap`](../interfaces/EventPayloadMap.md)

## Parameters

• **payload**: [`EventPayloadMap`](../interfaces/EventPayloadMap.md)\[`T`\]

## Returns

`Promise`\<`void`\>

## Defined in

[packages/core/src/types.ts:1683](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1683)
