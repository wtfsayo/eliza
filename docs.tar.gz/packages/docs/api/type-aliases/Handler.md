[@elizaos/core v1.0.0-beta.32](../index.md) / Handler

# Type Alias: Handler()

> **Handler**: (`runtime`, `message`, `state`?, `options`?, `callback`?, `responses`?) => `Promise`\<`unknown`\>

Handler function type for processing messages

## Parameters

• **runtime**: `IAgentRuntime`

• **message**: [`Memory`](../interfaces/Memory.md)

• **state?**: [`State`](../interfaces/State.md)

• **options?**

• **callback?**: [`HandlerCallback`](HandlerCallback.md)

• **responses?**: [`Memory`](../interfaces/Memory.md)[]

## Returns

`Promise`\<`unknown`\>

## Defined in

[packages/core/src/types.ts:251](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L251)
