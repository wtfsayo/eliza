[@elizaos/core v1.0.0-beta.32](../index.md) / MemoryTypeAlias

# Type Alias: MemoryTypeAlias

> **MemoryTypeAlias**: `string`

Memory type enumeration for built-in memory types

## Defined in

[packages/core/src/types.ts:127](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L127)
