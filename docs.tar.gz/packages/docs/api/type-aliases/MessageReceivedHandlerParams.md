[@elizaos/core v1.0.0-beta.32](../index.md) / MessageReceivedHandlerParams

# Type Alias: MessageReceivedHandlerParams

> **MessageReceivedHandlerParams**: `object`

Represents the parameters for a message received handler.

## Type declaration

### runtime

> **runtime**: `IAgentRuntime`

### message

> **message**: [`Memory`](../interfaces/Memory.md)

### callback

> **callback**: [`HandlerCallback`](HandlerCallback.md)

### onComplete()?

> `optional` **onComplete**: () => `void`

#### Returns

`void`

## Defined in

[packages/core/src/types.ts:1649](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1649)
