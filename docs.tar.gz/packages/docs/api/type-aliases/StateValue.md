[@elizaos/core v1.0.0-beta.32](../index.md) / StateValue

# Type Alias: StateValue

> **StateValue**: `string` \| `number` \| `boolean` \| `null` \| `StateObject` \| `StateArray`

Replace 'any' types with more specific types

## Defined in

[packages/core/src/types.ts:1902](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1902)
