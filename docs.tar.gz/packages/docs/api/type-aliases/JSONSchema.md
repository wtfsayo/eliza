[@elizaos/core v1.0.0-beta.32](../index.md) / JSONSchema

# Type Alias: JSONSchema

> **JSONSchema**: `object`

Optional JSON schema for validating generated objects

## Index Signature

 \[`key`: `string`\]: `any`

## Type declaration

### type

> **type**: `string`

### properties?

> `optional` **properties**: `Record`\<`string`, `any`\>

### required?

> `optional` **required**: `string`[]

### items?

> `optional` **items**: [`JSONSchema`](JSONSchema.md)

## Defined in

[packages/core/src/types.ts:1423](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1423)
