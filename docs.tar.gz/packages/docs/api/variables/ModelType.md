[@elizaos/core v1.0.0-beta.32](../index.md) / ModelType

# Variable: ModelType

> `const` **ModelType**: `object`

Model size/type classification

## Type declaration

### SMALL

> `readonly` **SMALL**: `"TEXT_SMALL"` = `'TEXT_SMALL'`

### MEDIUM

> `readonly` **MEDIUM**: `"TEXT_LARGE"` = `'TEXT_LARGE'`

### LARGE

> `readonly` **LARGE**: `"TEXT_LARGE"` = `'TEXT_LARGE'`

### TEXT\_SMALL

> `readonly` **TEXT\_SMALL**: `"TEXT_SMALL"` = `'TEXT_SMALL'`

### TEXT\_LARGE

> `readonly` **TEXT\_LARGE**: `"TEXT_LARGE"` = `'TEXT_LARGE'`

### TEXT\_EMBEDDING

> `readonly` **TEXT\_EMBEDDING**: `"TEXT_EMBEDDING"` = `'TEXT_EMBEDDING'`

### TEXT\_TOKENIZER\_ENCODE

> `readonly` **TEXT\_TOKENIZER\_ENCODE**: `"TEXT_TOKENIZER_ENCODE"` = `'TEXT_TOKENIZER_ENCODE'`

### TEXT\_TOKENIZER\_DECODE

> `readonly` **TEXT\_TOKENIZER\_DECODE**: `"TEXT_TOKENIZER_DECODE"` = `'TEXT_TOKENIZER_DECODE'`

### TEXT\_REASONING\_SMALL

> `readonly` **TEXT\_REASONING\_SMALL**: `"REASONING_SMALL"` = `'REASONING_SMALL'`

### TEXT\_REASONING\_LARGE

> `readonly` **TEXT\_REASONING\_LARGE**: `"REASONING_LARGE"` = `'REASONING_LARGE'`

### TEXT\_COMPLETION

> `readonly` **TEXT\_COMPLETION**: `"TEXT_COMPLETION"` = `'TEXT_COMPLETION'`

### IMAGE

> `readonly` **IMAGE**: `"IMAGE"` = `'IMAGE'`

### IMAGE\_DESCRIPTION

> `readonly` **IMAGE\_DESCRIPTION**: `"IMAGE_DESCRIPTION"` = `'IMAGE_DESCRIPTION'`

### TRANSCRIPTION

> `readonly` **TRANSCRIPTION**: `"TRANSCRIPTION"` = `'TRANSCRIPTION'`

### TEXT\_TO\_SPEECH

> `readonly` **TEXT\_TO\_SPEECH**: `"TEXT_TO_SPEECH"` = `'TEXT_TO_SPEECH'`

### AUDIO

> `readonly` **AUDIO**: `"AUDIO"` = `'AUDIO'`

### VIDEO

> `readonly` **VIDEO**: `"VIDEO"` = `'VIDEO'`

### OBJECT\_SMALL

> `readonly` **OBJECT\_SMALL**: `"OBJECT_SMALL"` = `'OBJECT_SMALL'`

### OBJECT\_LARGE

> `readonly` **OBJECT\_LARGE**: `"OBJECT_LARGE"` = `'OBJECT_LARGE'`

## Defined in

[packages/core/src/types.ts:73](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L73)
