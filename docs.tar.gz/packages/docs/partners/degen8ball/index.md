---
id: degen8ball
title: degen8ball
sidebar_position: 1
description: AI agent for crypto trading.
image: /img/partners/degen8ball.jpg
website: https://x.com/degen8ball
twitter: https://x.com/degen8ball
tags: ['Agent']
hide_table_of_contents: true
---

# degen8ball

<div className="partner-logo">
  <img src="/img/partners/degen8ball.jpg" alt="degen8ball logo" />
</div>

AI agent for crypto trading.

## About degen8ball

degen8ball is a key partner in our ecosystem, providing ai agent for crypto trading..

## Key Features

- Integration with degen8ball's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with degen8ball enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://x.com/degen8ball)
- [Source](https://x.com/degen8ball)
- [Twitter](https://x.com/degen8ball)
