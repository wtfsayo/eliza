---
id: tron
title: Tron
sidebar_position: 1
description: Decentralized content entertainment platform.
image: /img/partners/tron.jpg
website: https://trondao.org/
twitter: https://x.com/trondao
tags: ['Company']
hide_table_of_contents: true
---

# Tron

<div className="partner-logo">
  <img src="/img/partners/tron.jpg" alt="Tron logo" />
</div>

Decentralized content entertainment platform.

## About Tron

Tron is a key partner in our ecosystem, providing decentralized content entertainment platform..

## Key Features

- Integration with Tron's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Tron enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://trondao.org/)
- [Source](https://trondao.org/)
- [Twitter](https://x.com/trondao)
