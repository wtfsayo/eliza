---
id: magic-eden
title: Magic Eden
sidebar_position: 1
description: NFT marketplace.
image: /img/partners/magic-eden.jpg
website: https://magiceden.us
twitter:
tags: ['Company']
hide_table_of_contents: true
---

# Magic Eden

<div className="partner-logo">
  <img src="/img/partners/magic-eden.jpg" alt="Magic Eden logo" />
</div>

NFT marketplace.

## About Magic Eden

Magic Eden is a key partner in our ecosystem, providing nft marketplace..

## Key Features

- Integration with Magic Eden's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Magic Eden enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://magiceden.us)
- [Source](https://magiceden.us)
