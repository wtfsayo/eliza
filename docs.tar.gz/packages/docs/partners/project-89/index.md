---
id: project-89
title: Project 89
sidebar_position: 1
description: AI agent for Web3.
image: /img/partners/project-89.jpg
website: https://x.com/project_89
twitter: https://x.com/project_89
tags: ['Agent']
hide_table_of_contents: true
---

# Project 89

<div className="partner-logo">
  <img src="/img/partners/project-89.jpg" alt="Project 89 logo" />
</div>

AI agent for Web3.

## About Project 89

Project 89 is a key partner in our ecosystem, providing ai agent for web3..

## Key Features

- Integration with Project 89's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Project 89 enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://x.com/project_89)
- [Source](https://x.com/project_89)
- [Twitter](https://x.com/project_89)
