---
id: gaia-network
title: Gaia Network
sidebar_position: 1
description: Decentralized AI network.
image: /img/partners/gaia-network.jpg
website: https://www.gaianet.ai
twitter:
tags: ['Company']
hide_table_of_contents: true
---

# Gaia Network

<div className="partner-logo">
  <img src="/img/partners/gaia-network.jpg" alt="Gaia Network logo" />
</div>

Decentralized AI network.

## About Gaia Network

Gaia Network is a key partner in our ecosystem, providing decentralized ai network..

## Key Features

- Integration with Gaia Network's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Gaia Network enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://www.gaianet.ai)
- [Source](https://www.gaianet.ai)
