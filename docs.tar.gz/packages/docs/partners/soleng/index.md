---
id: soleng
title: Soleng
sidebar_position: 1
description: AI agent for Web3.
image: /img/partners/soleng.jpg
website: https://x.com/soleng_agent
twitter: https://x.com/soleng_ai
tags: ['Agent']
hide_table_of_contents: true
---

# Soleng

<div className="partner-logo">
  <img src="/img/partners/soleng.jpg" alt="Soleng logo" />
</div>

AI agent for Web3.

## About Soleng

Soleng is a key partner in our ecosystem, providing ai agent for web3..

## Key Features

- Integration with Soleng's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Soleng enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://x.com/soleng_agent)
- [Source](https://x.com/soleng_agent)
- [Twitter](https://x.com/soleng_ai)
