---
id: hume
title: hume
sidebar_position: 1
description: AI infrastructure.
image: /img/partners/hume.jpg
website: https://wearehume.com
twitter:
tags: ['Company']
hide_table_of_contents: true
---

# hume

<div className="partner-logo">
  <img src="/img/partners/hume.jpg" alt="hume logo" />
</div>

AI infrastructure.

## About hume

hume is a key partner in our ecosystem, providing ai infrastructure..

## Key Features

- Integration with hume's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with hume enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://wearehume.com)
- [Source](https://wearehume.com)
