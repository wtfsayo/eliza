---
id: elizas-sister
title: Eliza's Sister
sidebar_position: 1
description: AI agent for Web3.
image: /img/partners/elizas-sister.jpeg
website: https://x.com/elizas_sister
twitter: https://x.com/elizas_sister
tags: ['Agent']
hide_table_of_contents: true
---

# Eliza's Sister

<div className="partner-logo">
  <img src="/img/partners/elizas-sister.jpeg" alt="Eliza's Sister logo" />
</div>

AI agent for Web3.

## About Eliza's Sister

Eliza's Sister is a key partner in our ecosystem, providing ai agent for web3..

## Key Features

- Integration with Eliza's Sister's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Eliza's Sister enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://x.com/elizas_sister)
- [Source](https://x.com/elizas_sister)
- [Twitter](https://x.com/elizas_sister)
