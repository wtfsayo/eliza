---
id: zerebro
title: Zerebro
sidebar_position: 1
description: AI agent for Web3.
image: /img/partners/zerebro.jpg
website: https://zerebro.org/
twitter: https://x.com/0xzerebro
tags: ['Agent']
hide_table_of_contents: true
---

# Zerebro

<div className="partner-logo">
  <img src="/img/partners/zerebro.jpg" alt="Zerebro logo" />
</div>

AI agent for Web3.

## About Zerebro

Zerebro is a key partner in our ecosystem, providing ai agent for web3..

## Key Features

- Integration with Zerebro's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Zerebro enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://zerebro.org/)
- [Source](https://zerebro.org/)
- [Twitter](https://x.com/0xzerebro)
