---
id: scriptoshi
title: Scriptoshi
sidebar_position: 1
description: AI agent for Web3.
image: /img/partners/scriptoshi.jpg
website: https://x.com/script0shi
twitter: https://x.com/script0shi
tags: ['Agent']
hide_table_of_contents: true
---

# Scriptoshi

<div className="partner-logo">
  <img src="/img/partners/scriptoshi.jpg" alt="Scriptoshi logo" />
</div>

AI agent for Web3.

## About Scriptoshi

Scriptoshi is a key partner in our ecosystem, providing ai agent for web3..

## Key Features

- Integration with Scriptoshi's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Scriptoshi enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://x.com/script0shi)
- [Source](https://x.com/script0shi)
- [Twitter](https://x.com/script0shi)
