---
id: iq6900
title: IQ6900
sidebar_position: 1
description: AI agent for Web3.
image: /img/partners/iq6900.png
website: https://linktr.ee/IQ6900
twitter: https://x.com/IQ6900_
tags: ['Agent']
hide_table_of_contents: true
---

# IQ6900

<div className="partner-logo">
  <img src="/img/partners/iq6900.png" alt="IQ6900 logo" />
</div>

AI agent for Web3.

## About IQ6900

IQ6900 is a key partner in our ecosystem, providing ai agent for web3..

## Key Features

- Integration with IQ6900's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with IQ6900 enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://linktr.ee/IQ6900)
- [Source](https://linktr.ee/IQ6900)
- [Twitter](https://x.com/IQ6900_)
