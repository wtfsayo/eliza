---
id: fuel
title: Fuel
sidebar_position: 1
description: Modular execution layer.
image: /img/partners/fuel.jpg
website: https://fuel.network/
twitter:
tags: ['Company']
hide_table_of_contents: true
---

# Fuel

<div className="partner-logo">
  <img src="/img/partners/fuel.jpg" alt="Fuel logo" />
</div>

Modular execution layer.

## About Fuel

Fuel is a key partner in our ecosystem, providing modular execution layer..

## Key Features

- Integration with Fuel's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Fuel enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://fuel.network/)
- [Source](https://fuel.network/)
