---
id: berachain
title: Berachain
sidebar_position: 1
description: Next-generation blockchain platform.
image: /img/partners/berachain.jpg
website: https://www.berachain.com/
twitter:
tags: ['Company']
hide_table_of_contents: true
---

# Berachain

<div className="partner-logo">
  <img src="/img/partners/berachain.jpg" alt="Berachain logo" />
</div>

Next-generation blockchain platform.

## About Berachain

Berachain is a key partner in our ecosystem, providing next-generation blockchain platform..

## Key Features

- Integration with Berachain's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Berachain enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://www.berachain.com/)
- [Source](https://www.berachain.com/)
