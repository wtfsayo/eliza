---
id: godsdotfun
title: Godsdotfun
sidebar_position: 1
description: AI agent for Web3.
image: /img/partners/godsdotfun.jpg
website: https://gods.fun
twitter: https://x.com/godsdotfun
tags: ['Agent']
hide_table_of_contents: true
---

# Godsdotfun

<div className="partner-logo">
  <img src="/img/partners/godsdotfun.jpg" alt="Godsdotfun logo" />
</div>

AI agent for Web3.

## About Godsdotfun

Godsdotfun is a key partner in our ecosystem, providing ai agent for web3..

## Key Features

- Integration with Godsdotfun's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Godsdotfun enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://gods.fun)
- [Source](https://gods.fun)
- [Twitter](https://x.com/godsdotfun)
