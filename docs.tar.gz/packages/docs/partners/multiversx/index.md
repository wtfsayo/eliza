---
id: multiversx
title: MultiversX
sidebar_position: 1
description: Blockchain platform.
image: /img/partners/multiversx.jpg
website: https://multiversx.com/
twitter:
tags: ['Company']
hide_table_of_contents: true
---

# MultiversX

<div className="partner-logo">
  <img src="/img/partners/multiversx.jpg" alt="MultiversX logo" />
</div>

Blockchain platform.

## About MultiversX

MultiversX is a key partner in our ecosystem, providing blockchain platform..

## Key Features

- Integration with MultiversX's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with MultiversX enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://multiversx.com/)
- [Source](https://multiversx.com/)
