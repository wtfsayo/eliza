---
id: heurist-ai
title: Heurist.ai
sidebar_position: 1
description: AI research platform.
image: /img/partners/heurist-ai.jpg
website: https://heurist.ai
twitter:
tags: ['Company']
hide_table_of_contents: true
---

# Heurist.ai

<div className="partner-logo">
  <img src="/img/partners/heurist-ai.jpg" alt="Heurist.ai logo" />
</div>

AI research platform.

## About Heurist.ai

Heurist.ai is a key partner in our ecosystem, providing ai research platform..

## Key Features

- Integration with Heurist.ai's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Heurist.ai enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://heurist.ai)
- [Source](https://heurist.ai)
