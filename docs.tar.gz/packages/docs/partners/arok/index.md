---
id: arok
title: Arok
sidebar_position: 1
description: AI agent for venture capital.
image: /img/partners/arok.jpg
website: https://arok.vc
twitter:
tags: ['Agent']
hide_table_of_contents: true
---

# Arok

<div className="partner-logo">
  <img src="/img/partners/arok.jpg" alt="Arok logo" />
</div>

AI agent for venture capital.

## About Arok

Arok is a key partner in our ecosystem, providing ai agent for venture capital..

## Key Features

- Integration with Arok's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Arok enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://arok.vc)
- [Source](https://arok.vc)
