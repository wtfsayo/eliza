---
id: saga
title: Saga
sidebar_position: 1
description: Layer 1 blockchain platform.
image: /img/partners/saga.jpg
website: https://saga.xyz/
twitter:
tags: ['Company']
hide_table_of_contents: true
---

# Saga

<div className="partner-logo">
  <img src="/img/partners/saga.jpg" alt="Saga logo" />
</div>

Layer 1 blockchain platform.

## About Saga

Saga is a key partner in our ecosystem, providing layer 1 blockchain platform..

## Key Features

- Integration with Saga's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Saga enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://saga.xyz/)
- [Source](https://saga.xyz/)
