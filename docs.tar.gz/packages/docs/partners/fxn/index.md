---
id: fxn
title: FXN
sidebar_position: 1
description: AI agent for Web3.
image: /img/partners/fxn.jpg
website: https://x.com/joinFXN
twitter: https://x.com/joinFXN
tags: ['Agent']
hide_table_of_contents: true
---

# FXN

<div className="partner-logo">
  <img src="/img/partners/fxn.jpg" alt="FXN logo" />
</div>

AI agent for Web3.

## About FXN

FXN is a key partner in our ecosystem, providing ai agent for web3..

## Key Features

- Integration with FXN's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with FXN enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://x.com/joinFXN)
- [Source](https://x.com/joinFXN)
- [Twitter](https://x.com/joinFXN)
