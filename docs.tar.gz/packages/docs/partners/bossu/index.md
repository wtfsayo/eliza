---
id: bossu
title: Bossu
sidebar_position: 1
description: AI agent for Web3.
image: /img/partners/bossu.jpg
website: https://bossu.online
twitter:
tags: ['Agent']
hide_table_of_contents: true
---

# Bossu

<div className="partner-logo">
  <img src="/img/partners/bossu.jpg" alt="Bossu logo" />
</div>

AI agent for Web3.

## About Bossu

Bossu is a key partner in our ecosystem, providing ai agent for web3..

## Key Features

- Integration with Bossu's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Bossu enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://bossu.online)
- [Source](https://bossu.online)
