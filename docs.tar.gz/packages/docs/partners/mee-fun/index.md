---
id: mee-fun
title: Mee.fun
sidebar_position: 1
description: AI agent launcher for Web3.
image: /img/partners/mee-fun.png
website: https://mee.fun
twitter:
tags: ['Company']
hide_table_of_contents: true
---

# Mee.fun

<div className="partner-logo">
  <img src="/img/partners/mee-fun.png" alt="Mee.fun logo" />
</div>

AI agent launcher for Web3.

## About Mee.fun

Mee.fun is a key partner in our ecosystem, providing ai agent launcher for web3..

## Key Features

- Integration with Mee.fun's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Mee.fun enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://mee.fun)
- [Source](https://mee.fun)
