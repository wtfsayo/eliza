---
id: injective
title: Injective
sidebar_position: 1
description: Layer 1 blockchain optimized for DeFi applications.
image: /img/partners/injective.jpg
website: https://injective.com/
twitter: https://x.com/injective
tags: ['Company']
hide_table_of_contents: true
---

# Injective

<div className="partner-logo">
  <img src="/img/partners/injective.jpg" alt="Injective logo" />
</div>

Layer 1 blockchain optimized for DeFi applications.

## About Injective

Injective is a key partner in our ecosystem, providing layer 1 blockchain optimized for defi applications..

## Key Features

- Integration with Injective's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Injective enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://injective.com/)
- [Source](https://injective.com/)
- [Twitter](https://x.com/injective)
