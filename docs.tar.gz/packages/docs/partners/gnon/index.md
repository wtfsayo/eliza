---
id: gnon
title: GNON
sidebar_position: 1
description: AI agent for Web3.
image: /img/partners/gnon.jpg
website: https://x.com/gnonlabs
twitter: https://x.com/gnonlabs
tags: ['Agent']
hide_table_of_contents: true
---

# GNON

<div className="partner-logo">
  <img src="/img/partners/gnon.jpg" alt="GNON logo" />
</div>

AI agent for Web3.

## About GNON

GNON is a key partner in our ecosystem, providing ai agent for web3..

## Key Features

- Integration with GNON's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with GNON enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://x.com/gnonlabs)
- [Source](https://x.com/gnonlabs)
- [Twitter](https://x.com/gnonlabs)
