---
id: smolverse
title: Smolverse
sidebar_position: 1
description: Web3 gaming platform.
image: /img/partners/smolverse.png
website: https://smolverse.lol
twitter:
tags: ['Company']
hide_table_of_contents: true
---

# Smolverse

<div className="partner-logo">
  <img src="/img/partners/smolverse.png" alt="Smolverse logo" />
</div>

Web3 gaming platform.

## About Smolverse

Smolverse is a key partner in our ecosystem, providing web3 gaming platform..

## Key Features

- Integration with Smolverse's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with Smolverse enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://smolverse.lol)
- [Source](https://smolverse.lol)
