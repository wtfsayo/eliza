---
id: beffai
title: BeffAI
sidebar_position: 1
description: AI agent for DeFi.
image: /img/partners/beffai.jpg
website: https://x.com/BasedBeffAI
twitter: https://x.com/BasedBeffAI
tags: ['Agent']
hide_table_of_contents: true
---

# BeffAI

<div className="partner-logo">
  <img src="/img/partners/beffai.jpg" alt="BeffAI logo" />
</div>

AI agent for DeFi.

## About BeffAI

BeffAI is a key partner in our ecosystem, providing ai agent for defi..

## Key Features

- Integration with BeffAI's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with BeffAI enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://x.com/BasedBeffAI)
- [Source](https://x.com/BasedBeffAI)
- [Twitter](https://x.com/BasedBeffAI)
