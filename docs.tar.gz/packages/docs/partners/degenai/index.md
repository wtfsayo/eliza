---
id: degenai
title: degenai
sidebar_position: 1
description: AI agent for DeFi.
image: /img/partners/degenai.jpg
website: https://x.com/degenspartanai
twitter: https://x.com/degenspartanai
tags: ['Agent']
hide_table_of_contents: true
---

# degenai

<div className="partner-logo">
  <img src="/img/partners/degenai.jpg" alt="degenai logo" />
</div>

AI agent for DeFi.

## About degenai

degenai is a key partner in our ecosystem, providing ai agent for defi..

## Key Features

- Integration with degenai's platform
- Seamless user experience
- Enhanced functionality through partnership

## Integration with Eliza

Our partnership with degenai enables users to access their services directly through Eliza, providing a seamless experience for all users.

## Links

- [Website](https://x.com/degenspartanai)
- [Source](https://x.com/degenspartanai)
- [Twitter](https://x.com/degenspartanai)
